# INboard
Android keyboard (Kotlin, no external dependencies).

Made by **Incertus** - (c) 2026 Incertus. All rights reserved.

Build with GitHub Actions: push to `main`, then download the `INboard-apk` artifact.
