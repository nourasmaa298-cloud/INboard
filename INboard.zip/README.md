# IN-board
Android keyboard (Kotlin, no external dependencies): Liquid Glass + blur, 65 languages, emoji, word suggestions, translation.

Made by **Incertus** - (c) 2026 Incertus. All rights reserved.

Privacy: the keyboard does not store or learn what you type.

Build with GitHub Actions: push to `main`, then download the `INboard-apk` artifact.
