package com.inboard.keyboard

class Th(
    val nameEn: String,
    val nameAr: String,
    val dark: Boolean,
    val panel: Int,
    val letter: Int,
    val special: Int,
    val text: Int,
    val accent: Int
)

object Themes {
    val list: List<Th> = listOf(
        Th("Auto", "تلقائي", false, 0xFFD1D3D9.toInt(), 0xFFFFFFFF.toInt(), 0xFFABB0BC.toInt(), 0xFF111111.toInt(), 0xFF0A84FF.toInt()),
        Th("iOS Light", "آيفون فاتح", false, 0xFFD1D3D9.toInt(), 0xFFFFFFFF.toInt(), 0xFFABB0BC.toInt(), 0xFF111111.toInt(), 0xFF0A84FF.toInt()),
        Th("iOS Dark", "آيفون داكن", true, 0xFF1C1C1E.toInt(), 0xFF4A4A4E.toInt(), 0xFF2C2C2E.toInt(), 0xFFFFFFFF.toInt(), 0xFF0A84FF.toInt()),
        Th("AMOLED", "أسود AMOLED", true, 0xFF000000.toInt(), 0xFF1C1C1E.toInt(), 0xFF111113.toInt(), 0xFFFFFFFF.toInt(), 0xFF30D158.toInt()),
        Th("Ocean", "محيط", true, 0xFF0B2545.toInt(), 0xFF13315C.toInt(), 0xFF0A1F3A.toInt(), 0xFFEAF2FF.toInt(), 0xFF00B4D8.toInt()),
        Th("Sunset", "غروب", true, 0xFF3D1E2B.toInt(), 0xFF5C2A3A.toInt(), 0xFF40202D.toInt(), 0xFFFFF1E6.toInt(), 0xFFFF7A45.toInt()),
        Th("Rose", "وردي", false, 0xFFF8D7E0.toInt(), 0xFFFFFFFF.toInt(), 0xFFEBB1C4.toInt(), 0xFF4A1F2B.toInt(), 0xFFE91E63.toInt()),
        Th("Mint", "نعناع", false, 0xFFD3EFE1.toInt(), 0xFFFFFFFF.toInt(), 0xFFA6D8C0.toInt(), 0xFF12372A.toInt(), 0xFF10B981.toInt()),
        Th("Lavender", "لافندر", false, 0xFFE3DCF7.toInt(), 0xFFFFFFFF.toInt(), 0xFFC4B8EC.toInt(), 0xFF2A1F4D.toInt(), 0xFF7C4DFF.toInt()),
        Th("Graphite", "جرافيت", true, 0xFF2B2D31.toInt(), 0xFF45474D.toInt(), 0xFF34363B.toInt(), 0xFFF2F3F5.toInt(), 0xFF0A84FF.toInt())
    )

    val accents: List<Int> = listOf(
        0xFF0A84FF.toInt(), 0xFF30D158.toInt(), 0xFFFF9F0A.toInt(), 0xFFFF453A.toInt(),
        0xFFBF5AF2.toInt(), 0xFFFF375F.toInt(), 0xFF64D2FF.toInt(), 0xFFFFD60A.toInt(),
        0xFF00C7BE.toInt(), 0xFF8E8E93.toInt()
    )

    fun resolve(idx: Int, systemDark: Boolean): Th {
        val i = idx.coerceIn(0, list.size - 1)
        return if (i == 0) (if (systemDark) list[2] else list[1]) else list[i]
    }
}
