package com.inboard.keyboard

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

fun isWordChar(c: Char): Boolean {
    if (Character.isLetter(c) || c == '\'' || c == '\u2019') return true
    val t = Character.getType(c)
    return t == Character.NON_SPACING_MARK.toInt() || t == Character.COMBINING_SPACING_MARK.toInt()
}

/**
 * Word prediction: frequency dictionaries (downloaded per language, plus a tiny built-in
 * seed for English/Arabic) + words and word pairs learned from the user's own typing.
 */
object Predictor {

    private class Dict(val words: Array<String>, val set: HashSet<String>)

    private val dicts = ConcurrentHashMap<String, Dict>()
    private val loading = HashSet<String>()
    private val user = HashMap<String, Int>()
    private val bigram = HashMap<String, HashMap<String, Int>>()
    private var inited = false
    private var dirty = 0
    private val main = Handler(Looper.getMainLooper())

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        try {
            val f = File(ctx.filesDir, "user_dict.txt")
            if (f.exists()) {
                f.forEachLine { l ->
                    val p = l.split('\t')
                    if (p.size == 2) user[p[0]] = p[1].toIntOrNull() ?: 1
                }
            }
            val g = File(ctx.filesDir, "user_bigrams.txt")
            if (g.exists()) {
                g.forEachLine { l ->
                    val p = l.split('\t')
                    if (p.size == 3) {
                        val m = bigram.getOrPut(p[0]) { HashMap() }
                        m[p[1]] = p[2].toIntOrNull() ?: 1
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    fun hasDict(ctx: Context, code: String): Boolean = File(ctx.filesDir, "dict_$code.txt").exists()

    fun warm(ctx: Context, code: String) {
        if (dicts.containsKey(code)) return
        synchronized(loading) {
            if (!loading.add(code)) return
        }
        val app = ctx.applicationContext
        Thread {
            try {
                val f = File(app.filesDir, "dict_$code.txt")
                val list: List<String> =
                    if (f.exists()) f.readLines().map { it.substringBefore('\t') } else seed(code)
                if (list.isNotEmpty()) {
                    val arr = list.toTypedArray()
                    val set = HashSet<String>()
                    for (w in arr) set.add(w)
                    dicts[code] = Dict(arr, set)
                }
            } catch (_: Exception) {
            }
            synchronized(loading) { loading.remove(code) }
        }.start()
    }

    private fun seed(code: String): List<String> {
        val s = SEED[code] ?: return emptyList()
        return s.split(" ").filter { it.isNotEmpty() }
    }

    /** Downloads a frequency list (top 40k words) for [code]; callback runs on the main thread. */
    fun download(ctx: Context, code: String, cb: (Boolean) -> Unit) {
        val app = ctx.applicationContext
        Thread {
            var ok = false
            val base = "https://raw.githubusercontent.com/hermitdave/FrequencyWords/master/content/2018/$code/"
            for (name in listOf(code + "_50k.txt", code + "_full.txt")) {
                try {
                    val lines = fetch(base + name, 40000)
                    if (lines.size > 200) {
                        File(app.filesDir, "dict_$code.txt").writeText(lines.joinToString("\n"))
                        ok = true
                        break
                    }
                } catch (_: Exception) {
                }
            }
            if (ok) {
                dicts.remove(code)
                warm(app, code)
            }
            main.post { cb(ok) }
        }.start()
    }

    private fun fetch(u: String, limit: Int): List<String> {
        val out = ArrayList<String>()
        val con = URL(u).openConnection() as HttpURLConnection
        con.connectTimeout = 10000
        con.readTimeout = 20000
        try {
            if (con.responseCode != 200) return out
            val br = BufferedReader(InputStreamReader(con.inputStream, "UTF-8"))
            val seen = HashSet<String>()
            var line = br.readLine()
            while (line != null && out.size < limit) {
                val sp = line.lastIndexOf(' ')
                if (sp > 0) {
                    val w = line.substring(0, sp).lowercase()
                    val ok = w.length in 1..24 && w.all { isWordChar(it) }
                    if (ok && seen.add(w)) out.add(w + "\t" + line.substring(sp + 1))
                }
                line = br.readLine()
            }
            br.close()
        } finally {
            con.disconnect()
        }
        return out
    }

    fun suggest(code: String, prefix: String, prev: String, max: Int, cap: Boolean): List<String> {
        val d = dicts[code]
        val lp = prefix.lowercase()
        val out = ArrayList<String>()
        if (lp.isEmpty()) {
            val bg = bigram[prev]
            if (bg != null) {
                for (e in bg.entries.sortedByDescending { it.value }) {
                    if (out.size >= max) break
                    out.add(e.key)
                }
            }
            val sd = SEED_BG[prev]
            if (sd != null) {
                for (w in sd.split(" ")) {
                    if (out.size >= max) break
                    if (!out.contains(w)) out.add(w)
                }
            }
            if (d != null) {
                var i = 0
                while (out.size < max && i < d.words.size && i < 60) {
                    val w = d.words[i]
                    if (w.length > 1 && !out.contains(w)) out.add(w)
                    i++
                }
            }
        } else {
            val scored = HashMap<String, Double>()
            for ((w, c) in user) {
                if (w.length > lp.length && w.startsWith(lp)) scored[w] = 20000.0 + c * 3000.0
            }
            if (d != null) {
                var found = 0
                var i = 0
                while (i < d.words.size && found < max * 3) {
                    val w = d.words[i]
                    if (w.length > lp.length && w.startsWith(lp)) {
                        if (!scored.containsKey(w)) scored[w] = 100000.0 / (i + 20)
                        found++
                    }
                    i++
                }
            }
            val bg = bigram[prev]
            if (bg != null) {
                for ((w, c) in bg) {
                    val cur = scored[w]
                    if (cur != null) scored[w] = cur + c * 8000.0
                }
            }
            for (e in scored.entries.sortedByDescending { it.value }) {
                if (out.size >= max) break
                out.add(e.key)
            }
        }
        val upper = cap || (prefix.isNotEmpty() && prefix[0].isUpperCase())
        return if (upper) out.map { w -> w.replaceFirstChar { ch -> ch.uppercase() } } else out
    }

    /** Returns a likely correction for a mistyped word, or null if the word looks fine. */
    fun correct(code: String, w: String): String? {
        if (w.length < 3) return null
        val d = dicts[code] ?: return null
        val lw = w.lowercase()
        if (d.set.contains(lw) || user.containsKey(lw)) return null
        val lim = minOf(d.words.size, 20000)
        for (i in 0 until lim) {
            val c = d.words[i]
            if (c.isNotEmpty() && c[0] == lw[0] && Math.abs(c.length - lw.length) <= 1 && within1(c, lw)) {
                return if (w[0].isUpperCase()) c.replaceFirstChar { ch -> ch.uppercase() } else c
            }
        }
        return null
    }

    private fun within1(a: String, b: String): Boolean {
        if (a == b) return true
        val la = a.length
        val lb = b.length
        if (Math.abs(la - lb) > 1) return false
        var i = 0
        while (i < la && i < lb && a[i] == b[i]) i++
        if (la == lb) {
            if (i == la) return true
            if (a.substring(i + 1) == b.substring(i + 1)) return true
            if (i + 1 < la && a[i] == b[i + 1] && a[i + 1] == b[i] && a.substring(i + 2) == b.substring(i + 2)) return true
            return false
        }
        return if (la > lb) a.substring(i + 1) == b.substring(i) else b.substring(i + 1) == a.substring(i)
    }

    fun learn(ctx: Context, prev: String, word: String) {
        val w = word.lowercase()
        if (w.length < 2) return
        user[w] = (user[w] ?: 0) + 1
        if (prev.isNotEmpty()) {
            val m = bigram.getOrPut(prev) { HashMap() }
            m[w] = (m[w] ?: 0) + 1
        }
        dirty++
        if (dirty >= 25) save(ctx)
    }

    fun save(ctx: Context) {
        if (dirty == 0) return
        dirty = 0
        val app = ctx.applicationContext
        if (user.size > 8000) {
            val iter = user.entries.iterator()
            while (iter.hasNext()) {
                if (iter.next().value <= 1) iter.remove()
            }
        }
        val sb1 = StringBuilder()
        for ((w, c) in user) sb1.append(w).append('\t').append(c).append('\n')
        val sb2 = StringBuilder()
        var n = 0
        for ((p, m) in bigram) {
            for ((w, c) in m) {
                if (n < 30000) {
                    sb2.append(p).append('\t').append(w).append('\t').append(c).append('\n')
                    n++
                }
            }
        }
        val a = sb1.toString()
        val b = sb2.toString()
        Thread {
            try {
                File(app.filesDir, "user_dict.txt").writeText(a)
                File(app.filesDir, "user_bigrams.txt").writeText(b)
            } catch (_: Exception) {
            }
        }.start()
    }

    fun clearLearned(ctx: Context) {
        user.clear()
        bigram.clear()
        dirty = 0
        try {
            File(ctx.filesDir, "user_dict.txt").delete()
            File(ctx.filesDir, "user_bigrams.txt").delete()
        } catch (_: Exception) {
        }
    }

    private val SEED: Map<String, String> = mapOf(
        "en" to ("the be to of and a in that have i it for not on with he as you do at this but his by from they we say her she or an will my one all would there their what so up out if about who get which go me when make can like time no just him know take people into year your good some could them see other than then now look only come its over think also back after use two how our work first well way even new want because any these give day most us is are was were been has had did said am " +
            "hello hi thanks thank please yes okay ok sorry love great nice morning night today tomorrow home where why here need help right going really very much too still never always little long thing man woman child world life hand part place week company system program question during government number point mean tell feel try leave call keep let begin seem help talk turn start might show hear play run move live believe hold bring happen write provide sit stand lose pay meet include continue set learn change lead understand watch follow stop create speak read allow add spend grow open walk win offer remember consider appear buy wait serve die send expect build stay fall cut reach kill remain"),
        "ar" to "في من على إلى أن هذا هذه ذلك التي الذي ما لا نعم كان كانت يكون مع عن كل بعد قبل بين حتى أو لكن إذا كيف أين متى لماذا شكرا مرحبا أهلا السلام عليكم صباح الخير مساء الله إن شاء الحمد لله جدا اليوم غدا الآن هنا هناك أنا أنت هو هي نحن هم أريد أحب أعرف أستطيع يمكن من فضلك آسف عفوا تمام حسنا طيب جميل رائع صديق بيت عمل وقت يوم ليل ماء كتاب"
    )

    private val SEED_BG: Map<String, String> = mapOf(
        "i" to "am have will", "you" to "are can have", "the" to "best same first",
        "how" to "are to do", "what" to "is are do", "thank" to "you", "good" to "morning night luck",
        "see" to "you", "are" to "you", "do" to "you not", "it" to "is was will", "is" to "it a the",
        "to" to "be the do", "i'm" to "going not sure", "don't" to "know want have",
        "can" to "you i we", "will" to "be you do", "have" to "a to been", "we" to "are can will",
        "السلام" to "عليكم", "صباح" to "الخير", "مساء" to "الخير", "شكرا" to "لك جزيلا",
        "كيف" to "حالك الحال", "إن" to "شاء", "ما" to "هو هي", "أنا" to "في لا"
    )
}
