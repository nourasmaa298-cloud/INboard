package com.inboard.keyboard

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable

private fun argb(a: Float, r: Int, g: Int, b: Int): Int =
    Color.argb(a.coerceIn(0f, 255f).toInt(), r, g, b)

/**
 * "Liquid glass" keyboard panel: tinted translucent body (the real blur comes from the
 * window), a soft vertical gloss, a diagonal sheen, a thick faint rim and a bright
 * specular edge that is strong on top and fades towards the middle.
 */
class GlassPanelDrawable(
    private val tint: Int,
    private val radiusPx: Float,
    private val edge: Int,
    private val gloss: Int,
    private val dark: Boolean,
    private val bmp: Bitmap?,
    private val dim: Int,
    private val density: Float
) : Drawable() {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var lw = 0
    private var lh = 0
    private var glossShader: Shader? = null
    private var sheenShader: Shader? = null
    private var edgeShader: Shader? = null
    private var bmpShader: Shader? = null

    private fun build(w: Float, h: Float) {
        val g = gloss / 100f
        val e = edge / 100f
        glossShader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(
                argb(255f * 0.30f * g, 255, 255, 255),
                argb(255f * 0.04f * g, 255, 255, 255),
                Color.TRANSPARENT,
                argb(if (dark) 40f else 18f, 0, 0, 0)
            ),
            floatArrayOf(0f, 0.30f, 0.6f, 1f), Shader.TileMode.CLAMP
        )
        sheenShader = LinearGradient(
            0f, 0f, w, h * 0.7f,
            intArrayOf(Color.TRANSPARENT, argb(255f * 0.16f * g, 255, 255, 255), Color.TRANSPARENT),
            floatArrayOf(0f, 0.42f, 1f), Shader.TileMode.CLAMP
        )
        edgeShader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(
                argb(255f * 0.95f * e, 255, 255, 255),
                argb(255f * 0.16f * e, 255, 255, 255),
                argb(255f * 0.50f * e, 255, 255, 255)
            ),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        if (bmp != null) {
            val s = BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            val sc = maxOf(w / bmp.width, h / bmp.height)
            val m = Matrix()
            m.postScale(sc, sc)
            m.postTranslate((w - bmp.width * sc) / 2f, (h - bmp.height * sc) / 2f)
            s.setLocalMatrix(m)
            bmpShader = s
        } else {
            bmpShader = null
        }
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val w = b.width()
        val h = b.height()
        if (w <= 0 || h <= 0) return
        if (w != lw || h != lh) {
            lw = w
            lh = h
            build(w.toFloat(), h.toFloat())
        }
        canvas.save()
        canvas.translate(b.left.toFloat(), b.top.toFloat())
        rect.set(0f, 0f, w.toFloat(), h.toFloat())
        val r = minOf(radiusPx, rect.width() / 2f, rect.height() / 2f)

        p.style = Paint.Style.FILL
        if (bmpShader != null) {
            p.shader = bmpShader
            canvas.drawRoundRect(rect, r, r, p)
            p.shader = null
            p.color = argb(255f * dim / 100f, 0, 0, 0)
            canvas.drawRoundRect(rect, r, r, p)
        }
        p.shader = null
        p.color = tint
        canvas.drawRoundRect(rect, r, r, p)
        p.shader = glossShader
        canvas.drawRoundRect(rect, r, r, p)
        p.shader = sheenShader
        canvas.drawRoundRect(rect, r, r, p)
        p.shader = null

        // thick faint rim (gives the "glass thickness" look)
        p.style = Paint.Style.STROKE
        val rim = 6f * density
        p.strokeWidth = rim
        p.shader = edgeShader
        p.alpha = 42
        val ri = RectF(rim / 2f, rim / 2f, w - rim / 2f, h - rim / 2f)
        canvas.drawRoundRect(ri, maxOf(0f, r - rim / 2f), maxOf(0f, r - rim / 2f), p)

        // crisp specular edge
        val sw = 1.4f * density
        p.strokeWidth = sw
        p.alpha = 255
        val re = RectF(sw / 2f, sw / 2f, w - sw / 2f, h - sw / 2f)
        canvas.drawRoundRect(re, maxOf(0f, r - sw / 2f), maxOf(0f, r - sw / 2f), p)
        p.shader = null

        // outer hairline so light themes keep a visible border
        if (!dark) {
            p.strokeWidth = density
            p.color = argb(40f, 0, 0, 0)
            val ro = RectF(density / 2f, density / 2f, w - density / 2f, h - density / 2f)
            canvas.drawRoundRect(ro, r, r, p)
        }
        p.style = Paint.Style.FILL
        canvas.restore()
    }

    override fun setAlpha(alpha: Int) {}

    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** A single glass key / pill: soft shadow, gloss, bright rim and a touch glow while pressed. */
class GlassKeyDrawable(
    private val fill: Int,
    private val fillPressed: Int,
    private val radiusPx: Float,
    private val edge: Int,
    private val gloss: Int,
    private val dark: Boolean,
    private val glow: Boolean,
    private val liftPx: Float,
    private val density: Float
) : Drawable() {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val tmp = RectF()
    private var pressed = false
    private var tx = 0f
    private var ty = 0f
    private var lw = 0
    private var lh = 0
    private var glossShader: Shader? = null
    private var edgeShader: Shader? = null

    fun setPress(down: Boolean, x: Float, y: Float) {
        if (down == pressed && x == tx && y == ty) return
        pressed = down
        tx = x
        ty = y
        invalidateSelf()
    }

    private fun build(h: Float) {
        val g = gloss / 100f
        val e = edge / 100f
        glossShader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(argb(255f * 0.34f * g, 255, 255, 255), argb(255f * 0.05f * g, 255, 255, 255), Color.TRANSPARENT),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        edgeShader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(
                argb(255f * 0.75f * e, 255, 255, 255),
                argb(255f * 0.10f * e, 255, 255, 255),
                argb(255f * 0.34f * e, 255, 255, 255)
            ),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val w = b.width()
        val h = b.height()
        if (w <= 0 || h <= 0) return
        if (w != lw || h != lh) {
            lw = w
            lh = h
            build(h.toFloat() - liftPx)
        }
        canvas.save()
        canvas.translate(b.left.toFloat(), b.top.toFloat())
        rect.set(0f, 0f, w.toFloat(), h.toFloat() - liftPx)
        val r = minOf(radiusPx, rect.width() / 2f, rect.height() / 2f)

        p.style = Paint.Style.FILL
        p.shader = null
        if (liftPx > 0f) {
            tmp.set(rect.left, rect.top + liftPx, rect.right, rect.bottom + liftPx)
            p.color = argb(if (dark) 70f else 46f, 0, 0, 0)
            canvas.drawRoundRect(tmp, r, r, p)
        }
        p.color = if (pressed) fillPressed else fill
        canvas.drawRoundRect(rect, r, r, p)
        p.shader = glossShader
        canvas.drawRoundRect(rect, r, r, p)

        if (pressed && glow) {
            val rad = maxOf(rect.width(), rect.height()) * 0.9f
            p.shader = RadialGradient(
                tx, ty, rad,
                intArrayOf(argb(255f * 0.45f * (gloss / 100f + 0.3f), 255, 255, 255), Color.TRANSPARENT),
                null, Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(rect, r, r, p)
        }

        p.shader = edgeShader
        p.style = Paint.Style.STROKE
        val sw = 0.9f * density
        p.strokeWidth = sw
        val ri = RectF(sw / 2f, sw / 2f, rect.right - sw / 2f, rect.bottom - sw / 2f)
        canvas.drawRoundRect(ri, maxOf(0f, r - sw / 2f), maxOf(0f, r - sw / 2f), p)
        p.shader = null
        p.style = Paint.Style.FILL
        canvas.restore()
    }

    override fun setAlpha(alpha: Int) {}

    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
