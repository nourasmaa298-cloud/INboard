package com.inboard.keyboard

class Lang(
    val code: String,
    val name: String,
    val rows: List<String>,
    val cased: Boolean,
    val dict: String,
    val rtl: Boolean = false
)

object Langs {
    private const val QW = "qwertyuiop"
    private const val AS = "asdfghjkl"
    private const val ZX = "zxcvbnm"

    private val DEV = listOf("अआइईउऊएऐओऔ", "कखगघचछजझटठ", "डढणतथदधनपफ", "बभमयरलवशषस", "हािीुूेैोौं")

    val all: List<Lang> = listOf(
        Lang("en", "English", listOf(QW, AS, ZX), true, "en"),
        Lang("ar", "العربية", listOf("ضصثقفغعهخحج", "شسيبلاتنمكد", "ذئؤرىةوزظط"), false, "ar", true),
        Lang("es", "Español", listOf(QW, "asdfghjklñ", ZX), true, "es"),
        Lang("fr", "Français", listOf("azertyuiop", "qsdfghjklm", "wxcvbn"), true, "fr"),
        Lang("de", "Deutsch", listOf("qwertzuiopü", "asdfghjklöä", "yxcvbnm"), true, "de"),
        Lang("it", "Italiano", listOf(QW, AS, ZX), true, "it"),
        Lang("pt", "Português", listOf(QW, AS, ZX), true, "pt"),
        Lang("ru", "Русский", listOf("йцукенгшщзхъ", "фывапролджэ", "ячсмитьбю"), true, "ru"),
        Lang("tr", "Türkçe", listOf("qwertyuıopğü", "asdfghjklşi", "zxcvbnmöç"), true, "tr"),
        Lang("fa", "فارسی", listOf("ضصثقفغعهخحجچ", "شسیبلاتنمکگ", "ظطزرذدپو"), false, "fa", true),
        Lang("ur", "اردو", listOf("قوعرتیےءہپ", "اسدفگحجکل", "زشچطبنم"), false, "ur", true),
        Lang("he", "עברית", listOf("קראטוןםפ", "שדגכעיחלךף", "זסבהנמצתץ"), false, "he", true),
        Lang("ps", "پښتو", listOf("ضصثقفغعهخحجچ", "شسیبلاتنمکګ", "ظطزرذدپوږ"), false, "", true),
        Lang("ckb", "کوردی", listOf("قوەرتیئحۆپ", "ئاسدفگھژکل", "زخجڤبنمێ"), false, "", true),
        Lang("nl", "Nederlands", listOf(QW, AS, ZX), true, "nl"),
        Lang("sv", "Svenska", listOf("qwertyuiopå", "asdfghjklöä", ZX), true, "sv"),
        Lang("da", "Dansk", listOf("qwertyuiopå", "asdfghjklæø", ZX), true, "da"),
        Lang("no", "Norsk", listOf("qwertyuiopå", "asdfghjkløæ", ZX), true, "no"),
        Lang("fi", "Suomi", listOf("qwertyuiopå", "asdfghjklöä", ZX), true, "fi"),
        Lang("is", "Íslenska", listOf("qwertyuiopð", "asdfghjklæþ", "zxcvbnmö"), true, "is"),
        Lang("pl", "Polski", listOf(QW, "asdfghjklł", "zxcvbnmż"), true, "pl"),
        Lang("cs", "Čeština", listOf("qwertzuiopú", "asdfghjklů", "yxcvbnm"), true, "cs"),
        Lang("sk", "Slovenčina", listOf("qwertzuiopú", "asdfghjklô", "yxcvbnmä"), true, "sk"),
        Lang("sl", "Slovenščina", listOf("qwertzuiopš", "asdfghjklč", "yxcvbnmž"), true, "sl"),
        Lang("hr", "Hrvatski", listOf("qwertzuiopš", "asdfghjklčć", "yxcvbnmžđ"), true, "hr"),
        Lang("bs", "Bosanski", listOf("qwertzuiopš", "asdfghjklčć", "yxcvbnmžđ"), true, "bs"),
        Lang("sq", "Shqip", listOf("qwertyuiopë", "asdfghjklç", ZX), true, "sq"),
        Lang("ro", "Română", listOf("qwertyuiopă", "asdfghjklșț", "zxcvbnmâî"), true, "ro"),
        Lang("hu", "Magyar", listOf("qwertzuiopő", "asdfghjkléá", "yxcvbnmíű"), true, "hu"),
        Lang("lt", "Lietuvių", listOf("qwertyuiopė", "asdfghjklą", "zxcvbnmčš"), true, "lt"),
        Lang("lv", "Latviešu", listOf("qwertyuiopū", "asdfghjklķļ", "zxcvbnmčš"), true, "lv"),
        Lang("et", "Eesti", listOf("qwertyuiopü", "asdfghjklöä", "zxcvbnmõ"), true, "et"),
        Lang("ca", "Català", listOf(QW, AS, "zxcvbnmç"), true, "ca"),
        Lang("gl", "Galego", listOf(QW, "asdfghjklñ", ZX), true, "gl"),
        Lang("eu", "Euskara", listOf(QW, "asdfghjklñ", "zxcvbnmç"), true, "eu"),
        Lang("af", "Afrikaans", listOf(QW, AS, ZX), true, "af"),
        Lang("sw", "Kiswahili", listOf(QW, AS, ZX), true, ""),
        Lang("id", "Indonesia", listOf(QW, AS, ZX), true, "id"),
        Lang("ms", "Bahasa Melayu", listOf(QW, AS, ZX), true, "ms"),
        Lang("tl", "Filipino", listOf(QW, AS, ZX), true, "tl"),
        Lang("vi", "Tiếng Việt", listOf("qwertyuiopđ", AS, ZX), true, "vi"),
        Lang("az", "Azərbaycan", listOf("qüertyuiopöğ", "asdfghjklıəş", "zxcvbnmç"), true, ""),
        Lang("uz", "Oʻzbek", listOf("qwertyuiopʻ", AS, ZX), true, ""),
        Lang("ku", "Kurdî", listOf("qwertyuiopê", "asdfghjklşî", "zxcvbnmçû"), true, ""),
        Lang("uk", "Українська", listOf("йцукенгшщзхї", "фівапролджє", "ячсмитьбюґ"), true, "uk"),
        Lang("bg", "Български", listOf("яертъуиопчшщ", "асдфгхйклю", "зьцжвбнм"), true, "bg"),
        Lang("sr", "Српски", listOf("љњертзуиопшђ", "асдфгхјклчћ", "жџцвбнм"), true, "sr"),
        Lang("mk", "Македонски", listOf("љњертѕуиопшѓ", "асдфгхјклчќ", "зџцвбнм"), true, "mk"),
        Lang("be", "Беларуская", listOf("йцукенгшўзх", "фывапролджэ", "ячсмітьбю"), true, ""),
        Lang("kk", "Қазақша", listOf("йцукенгшщзх", "фывапролджэ", "ячсмитьбю", "әіңғүұқөһ"), true, "kk"),
        Lang("mn", "Монгол", listOf("фцуженгшүзкъ", "йыбөахролдп", "яэчёсмитьвю"), true, ""),
        Lang("el", "Ελληνικά", listOf("ςερτυθιοπ", "ασδφγηξκλ", "ζχψωβνμ"), true, "el"),
        Lang("hy", "Հայերեն", listOf("աբգդեզէըթժիլխ", "ծկհձղճմյնշոչպ", "ջռսվտրցւփքօֆ"), true, "hy"),
        Lang("ka", "ქართული", listOf("აბგდევზთიკლმნ", "ოპჟრსტუფქღყშ", "ჩცძწჭხჯჰ"), false, "ka"),
        Lang("hi", "हिन्दी", DEV, false, "hi"),
        Lang("mr", "मराठी", DEV, false, ""),
        Lang("ne", "नेपाली", DEV, false, ""),
        Lang("bn", "বাংলা", listOf("অআইঈউঊএঐওঔ", "কখগঘঙচছজঝঞ", "টঠডঢণতথদধন", "পফবভমযরলশষ", "সহািীুূেৈোৌং"), false, "bn"),
        Lang("ta", "தமிழ்", listOf("அஆஇஈஉஊஎஏஐஒ", "ஓஔகஙசஞடணதந", "பமயரலவழளறன", "ாிீுூெேைொோௌ்"), false, "ta"),
        Lang("te", "తెలుగు", listOf("అఆఇఈఉఊఎఏఐఒఓఔ", "కఖగఘఙచఛజఝఞట", "ఠడఢణతథదధనపఫ", "బభమయరలవశషసహళ", "ాిీుూెేైొోౌ్ంః"), false, "te"),
        Lang("ml", "മലയാളം", listOf("അആഇഈഉഊഎഏഐഒഓഔ", "കഖഗഘങചഛജഝഞടഠ", "ഡഢണതഥദധനപഫബഭ", "മയരലവശഷസഹളഴറ", "ാിീുൂെേൈൊോൗ്ം"), false, "ml"),
        Lang("kn", "ಕನ್ನಡ", listOf("ಅಆಇಈಉಊಎಏಐಒಓಔ", "ಕಖಗಘಙಚಛಜಝಞಟಠ", "ಡಢಣತಥದಧನಪಫಬಭ", "ಮಯರಲವಶಷಸಹಳ", "ಾಿೀುೂೆೇೈೊೋೌ್ಂ"), false, ""),
        Lang("gu", "ગુજરાતી", listOf("અઆઇઈઉઊએઐઓઔ", "કખગઘઙચછજઝઞટઠ", "ડઢણતથદધનપફબભ", "મયરલવશષસહળ", "ાિીુૂેૈોૌ્ં"), false, ""),
        Lang("pa", "ਪੰਜਾਬੀ", listOf("ਅਆਇਈਉਊਏਐਓਔ", "ਕਖਗਘਙਚਛਜਝਞ", "ਟਠਡਢਣਤਥਦਧਨ", "ਪਫਬਭਮਯਰਲਵਸਹ", "ਾਿੀੁੂੇੈੋੌ੍ਂ"), false, ""),
        Lang("th", "ไทย", listOf("กขคฆงจฉชซญฎฏฐฑ", "ฒณดตถทธนบปผฝพฟ", "ภมยรลวศษสหฬอฮ", "ะัาำิีึืุูเแโใไ", "็่้๊๋์ๆฯ"), false, "th")
    )

    fun byCode(c: String): Lang? = all.firstOrNull { it.code == c }

    private val latin: Map<Char, String> = mapOf(
        'a' to "àáâäæãåāăą", 'c' to "çćčĉ", 'e' to "èéêëēęě", 'i' to "ìíîïīį",
        'o' to "òóôöõøœō", 'u' to "ùúûüūůű", 'n' to "ñńň", 's' to "śšşß",
        'y' to "ýÿ", 'z' to "žźż", 'l' to "łľ", 'd' to "ďđ", 'g' to "ğ",
        'r' to "řŕ", 't' to "ťţ", 'w' to "ŵ"
    )
    private val viet: Map<Char, String> = mapOf(
        'a' to "àáảãạăắằẳẵặâấầẩẫậ", 'e' to "èéẻẽẹêếềểễệ", 'i' to "ìíỉĩị",
        'o' to "òóỏõọôốồổỗộơớờởỡợ", 'u' to "ùúủũụưứừửữự", 'y' to "ỳýỷỹỵ"
    )
    private val arabic: Map<Char, String> = mapOf(
        'ا' to "أإآء", 'و' to "ؤ", 'ي' to "ئى", 'ه' to "ة", 'ك' to "ک"
    )
    private val persian: Map<Char, String> = mapOf('ا' to "آأ", 'ی' to "ي", 'ک' to "ك")
    private val noAlts: Set<String> = setOf(
        "uk", "bg", "sr", "mk", "be", "kk", "mn", "el", "he", "hi", "mr", "ne", "bn", "ta", "te",
        "ml", "kn", "gu", "pa", "th", "ka", "hy"
    )

    /** Long-press alternatives for a key (null if none). */
    fun alts(lang: Lang, ch: Char): String? {
        val raw: String? = when (lang.code) {
            "ar" -> arabic[ch]
            "fa", "ur", "ps", "ckb" -> persian[ch]
            "ru" -> if (ch == 'е') "ё" else null
            "vi" -> viet[ch]
            in noAlts -> null
            else -> latin[ch]
        }
        if (raw == null) return null
        val own = lang.rows.joinToString("")
        val f = raw.filter { !own.contains(it) }
        return if (f.isEmpty()) null else f
    }
}

object TrLangs {
    val list: List<Pair<String, String>> = listOf(
        "auto" to "Auto-detect / تلقائي",
        "en" to "English", "ar" to "العربية", "es" to "Español", "fr" to "Français",
        "de" to "Deutsch", "it" to "Italiano", "pt" to "Português", "ru" to "Русский",
        "tr" to "Türkçe", "fa" to "فارسی", "ur" to "اردو", "he" to "עברית",
        "hi" to "हिन्दी", "bn" to "বাংলা", "id" to "Indonesia", "ms" to "Melayu",
        "nl" to "Nederlands", "sv" to "Svenska", "da" to "Dansk", "no" to "Norsk",
        "fi" to "Suomi", "pl" to "Polski", "cs" to "Čeština", "uk" to "Українська",
        "el" to "Ελληνικά", "ro" to "Română", "hu" to "Magyar", "bg" to "Български",
        "sr" to "Српски", "hr" to "Hrvatski", "sk" to "Slovenčina", "th" to "ไทย",
        "vi" to "Tiếng Việt", "ko" to "한국어", "ja" to "日本語", "zh-CN" to "中文 (简体)",
        "zh-TW" to "中文 (繁體)", "sw" to "Kiswahili", "ku" to "Kurdî", "ps" to "پښتو",
        "sd" to "سنڌي", "ug" to "ئۇيغۇرچە", "yi" to "ייִדיש", "am" to "አማርኛ",
        "af" to "Afrikaans", "sq" to "Shqip", "hy" to "Հայերեն", "az" to "Azərbaycan",
        "eu" to "Euskara", "be" to "Беларуская", "bs" to "Bosanski", "ca" to "Català",
        "ceb" to "Cebuano", "co" to "Corsu", "cy" to "Cymraeg", "eo" to "Esperanto",
        "et" to "Eesti", "tl" to "Filipino", "fy" to "Frysk", "gl" to "Galego",
        "ka" to "ქართული", "gu" to "ગુજરાતી", "ht" to "Kreyòl ayisyen", "ha" to "Hausa",
        "haw" to "ʻŌlelo Hawaiʻi", "is" to "Íslenska", "ig" to "Igbo", "ga" to "Gaeilge",
        "jw" to "Basa Jawa", "kn" to "ಕನ್ನಡ", "kk" to "Қазақша", "km" to "ខ្មែរ",
        "rw" to "Kinyarwanda", "ky" to "Кыргызча", "lo" to "ລາວ", "la" to "Latina",
        "lv" to "Latviešu", "lt" to "Lietuvių", "lb" to "Lëtzebuergesch", "mk" to "Македонски",
        "mg" to "Malagasy", "ml" to "മലയാളം", "mt" to "Malti", "mi" to "Māori",
        "mr" to "मराठी", "mn" to "Монгол", "my" to "မြန်မာ", "ne" to "नेपाली",
        "ny" to "Chichewa", "or" to "ଓଡ଼ିଆ", "pa" to "ਪੰਜਾਬੀ", "sm" to "Gagana Samoa",
        "gd" to "Gàidhlig", "st" to "Sesotho", "sn" to "Shona", "si" to "සිංහල",
        "sl" to "Slovenščina", "so" to "Soomaali", "su" to "Basa Sunda", "tg" to "Тоҷикӣ",
        "ta" to "தமிழ்", "tt" to "Татарча", "te" to "తెలుగు", "tk" to "Türkmen",
        "uz" to "Oʻzbek", "xh" to "isiXhosa", "yo" to "Yorùbá", "zu" to "isiZulu"
    )

    fun name(code: String): String = list.firstOrNull { it.first == code }?.second ?: code
}
