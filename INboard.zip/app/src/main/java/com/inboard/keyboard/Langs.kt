package com.inboard.keyboard

class Lang(
    val code: String,
    val name: String,
    val rows: List<String>,
    val cased: Boolean,
    val dict: String
)

object Langs {
    private const val QW = "qwertyuiop"

    val all: List<Lang> = listOf(
        Lang("en", "English", listOf(QW, "asdfghjkl", "zxcvbnm"), true, "en"),
        Lang("ar", "العربية", listOf("ضصثقفغعهخحج", "شسيبلاتنمكد", "ذئؤرىةوزظط"), false, "ar"),
        Lang("es", "Español", listOf(QW, "asdfghjklñ", "zxcvbnm"), true, "es"),
        Lang("fr", "Français", listOf("azertyuiop", "qsdfghjklm", "wxcvbn"), true, "fr"),
        Lang("de", "Deutsch", listOf("qwertzuiopü", "asdfghjklöä", "yxcvbnm"), true, "de"),
        Lang("it", "Italiano", listOf(QW, "asdfghjkl", "zxcvbnm"), true, "it"),
        Lang("pt", "Português", listOf(QW, "asdfghjkl", "zxcvbnm"), true, "pt"),
        Lang("nl", "Nederlands", listOf(QW, "asdfghjkl", "zxcvbnm"), true, "nl"),
        Lang("sv", "Svenska", listOf("qwertyuiopå", "asdfghjklöä", "zxcvbnm"), true, "sv"),
        Lang("da", "Dansk", listOf("qwertyuiopå", "asdfghjklæø", "zxcvbnm"), true, "da"),
        Lang("no", "Norsk", listOf("qwertyuiopå", "asdfghjkløæ", "zxcvbnm"), true, "no"),
        Lang("fi", "Suomi", listOf("qwertyuiopå", "asdfghjklöä", "zxcvbnm"), true, "fi"),
        Lang("pl", "Polski", listOf(QW, "asdfghjklł", "zxcvbnmż"), true, "pl"),
        Lang("cs", "Čeština", listOf("qwertzuiopú", "asdfghjklů", "yxcvbnm"), true, "cs"),
        Lang("ro", "Română", listOf("qwertyuiopă", "asdfghjklșț", "zxcvbnmâî"), true, "ro"),
        Lang("hu", "Magyar", listOf("qwertzuiopő", "asdfghjkléá", "yxcvbnmíű"), true, "hu"),
        Lang("tr", "Türkçe", listOf("qwertyuıopğü", "asdfghjklşi", "zxcvbnmöç"), true, "tr"),
        Lang("id", "Indonesia", listOf(QW, "asdfghjkl", "zxcvbnm"), true, "id"),
        Lang("ru", "Русский", listOf("йцукенгшщзхъ", "фывапролджэ", "ячсмитьбю"), true, "ru"),
        Lang("uk", "Українська", listOf("йцукенгшщзхї", "фівапролджє", "ячсмитьбюґ"), true, "uk"),
        Lang("el", "Ελληνικά", listOf("ςερτυθιοπ", "ασδφγηξκλ", "ζχψωβνμ"), true, "el"),
        Lang("he", "עברית", listOf("קראטוןםפ", "שדגכעיחלךף", "זסבהנמצתץ"), false, "he"),
        Lang("fa", "فارسی", listOf("ضصثقفغعهخحجچ", "شسیبلاتنمکگ", "ظطزرذدپو"), false, "fa"),
        Lang("ur", "اردو", listOf("قوعرتیےءہپ", "اسدفگحجکل", "زشچطبنم"), false, "ur"),
        Lang("hi", "हिन्दी", listOf("कखगघचछजझटठ", "डढणतथदधनपफ", "बभमयरलवशषस", "हािीुूेैोौं"), false, "hi")
    )

    fun byCode(c: String): Lang? = all.firstOrNull { it.code == c }

    private val latin: Map<Char, String> = mapOf(
        'a' to "àáâäæãåāăą", 'c' to "çćčĉ", 'e' to "èéêëēęě", 'i' to "ìíîïīį",
        'o' to "òóôöõøœō", 'u' to "ùúûüūůű", 'n' to "ñńň", 's' to "śšşß",
        'y' to "ýÿ", 'z' to "žźż", 'l' to "łľ", 'd' to "ďđ", 'g' to "ğ",
        'r' to "řŕ", 't' to "ťţ", 'w' to "ŵ"
    )
    private val arabic: Map<Char, String> = mapOf(
        'ا' to "أإآء", 'و' to "ؤ", 'ي' to "ئى", 'ه' to "ة", 'ك' to "ک"
    )
    private val persian: Map<Char, String> = mapOf('ا' to "آأ", 'ی' to "ي", 'ک' to "ك")

    /** Long-press alternatives for a key (null if none). */
    fun alts(lang: Lang, ch: Char): String? {
        val raw: String? = when (lang.code) {
            "ar" -> arabic[ch]
            "fa", "ur" -> persian[ch]
            "ru" -> if (ch == 'е') "ё" else null
            "uk", "el", "he", "hi" -> null
            else -> latin[ch]
        }
        if (raw == null) return null
        val own = lang.rows.joinToString("")
        val f = raw.filter { !own.contains(it) }
        return if (f.isEmpty()) null else f
    }
}

object TrLangs {
    val list: List<Pair<String, String>> = listOf(
        "auto" to "Auto-detect / تلقائي",
        "en" to "English", "ar" to "العربية", "es" to "Español", "fr" to "Français",
        "de" to "Deutsch", "it" to "Italiano", "pt" to "Português", "ru" to "Русский",
        "tr" to "Türkçe", "fa" to "فارسی", "ur" to "اردو", "he" to "עברית",
        "hi" to "हिन्दी", "bn" to "বাংলা", "id" to "Indonesia", "ms" to "Melayu",
        "nl" to "Nederlands", "sv" to "Svenska", "da" to "Dansk", "no" to "Norsk",
        "fi" to "Suomi", "pl" to "Polski", "cs" to "Čeština", "uk" to "Українська",
        "el" to "Ελληνικά", "ro" to "Română", "hu" to "Magyar", "bg" to "Български",
        "sr" to "Српски", "hr" to "Hrvatski", "sk" to "Slovenčina", "th" to "ไทย",
        "vi" to "Tiếng Việt", "ko" to "한국어", "ja" to "日本語", "zh-CN" to "中文",
        "sw" to "Kiswahili", "ku" to "Kurdî"
    )

    fun name(code: String): String = list.firstOrNull { it.first == code }?.second ?: code
}
