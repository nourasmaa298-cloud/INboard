package com.inboard.keyboard

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private var sp: SharedPreferences? = null

    fun get(ctx: Context): SharedPreferences {
        val s = sp
        if (s != null) return s
        val n = ctx.applicationContext.getSharedPreferences("inboard", Context.MODE_PRIVATE)
        sp = n
        return n
    }
}
