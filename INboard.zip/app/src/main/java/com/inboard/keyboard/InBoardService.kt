package com.inboard.keyboard

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class InBoardService : InputMethodService() {

    private enum class Layer { LETTERS, NUMBERS, SYMBOLS, EMOJI }

    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())
    private var root: LinearLayout? = null

    private var layer = Layer.LETTERS
    private var arabic = false
    private var shift = 0 // 0 = off, 1 = once, 2 = caps lock
    private var lastShiftTap = 0L
    private var lastSpace = 0L

    // theme colors
    private var dark = false
    private var cPanel = 0
    private var cLetter = 0
    private var cLetterP = 0
    private var cSpecial = 0
    private var cSpecialP = 0
    private var cText = 0
    private val cAccent = 0xFF0A84FF.toInt()
    private val cAccentP = 0xFF0066CC.toInt()

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("inboard", Context.MODE_PRIVATE)
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        try {
            window.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        } catch (_: Throwable) {
        }
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.layoutDirection = View.LAYOUT_DIRECTION_LTR
        root = c
        render()
        return c
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        layer = Layer.LETTERS
        var caps = 0
        if (info != null && info.inputType != 0) {
            caps = currentInputConnection?.getCursorCapsMode(info.inputType) ?: 0
        }
        shift = if (!arabic && caps != 0) 1 else 0
        render()
        applyBlur()
    }

    // ------------------------------------------------------------------ theme / blur

    private fun loadTheme() {
        dark = when (prefs.getInt("theme", 0)) {
            1 -> false
            2 -> true
            else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
        }
        if (dark) {
            cPanel = 0xCC121214.toInt()
            cLetter = 0xB34A4A4E.toInt()
            cLetterP = 0xE6808085.toInt()
            cSpecial = 0xB32A2A2D.toInt()
            cSpecialP = 0xE64A4A4E.toInt()
            cText = Color.WHITE
        } else {
            cPanel = 0xCCD6D8DE.toInt()
            cLetter = 0xE6FFFFFF.toInt()
            cLetterP = 0xFFC7C9D1.toInt()
            cSpecial = 0xB3AFB3BD.toInt()
            cSpecialP = 0xFFFFFFFF.toInt()
            cText = 0xFF111111.toInt()
        }
    }

    private fun applyBlur() {
        if (Build.VERSION.SDK_INT < 31) return
        try {
            val w = window.window ?: return
            if (prefs.getBoolean("blur", true)) {
                w.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                val lp = w.attributes
                lp.blurBehindRadius = 40
                w.attributes = lp
                w.setBackgroundBlurRadius(60)
            } else {
                w.setBackgroundBlurRadius(0)
            }
        } catch (_: Throwable) {
        }
    }

    // ------------------------------------------------------------------ rendering

    private fun render() {
        val c = root ?: return
        loadTheme()
        c.removeAllViews()

        val r = dp(26).toFloat()
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.RECTANGLE
        bg.setColor(cPanel)
        bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        c.background = bg
        c.setPadding(dp(4), dp(2), dp(4), dp(8))

        c.addView(topBar())

        val h = when (prefs.getInt("height", 1)) {
            0 -> 46
            2 -> 58
            else -> 52
        }

        when (layer) {
            Layer.LETTERS -> {
                val rows = if (arabic) {
                    listOf("ضصثقفغعهخحج", "شسيبلاتنمكد", "ذئؤرىةوزظط")
                } else {
                    listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
                }
                c.addView(row(h, rows[0].map { letter(it) }))
                c.addView(row(h, buildList<View> {
                    if (!arabic) add(spacer(0.5f))
                    rows[1].forEach { add(letter(it)) }
                    if (!arabic) add(spacer(0.5f))
                }))
                c.addView(row(h, buildList<View> {
                    if (!arabic) add(shiftKey())
                    rows[2].forEach { add(letter(it)) }
                    add(deleteKey())
                }))
                c.addView(bottomRow(h))
            }

            Layer.NUMBERS, Layer.SYMBOLS -> {
                val sym = layer == Layer.SYMBOLS
                val r1 = if (sym) "[]{}#%^*+=" else "1234567890"
                val r2 = if (sym) "_\\|~<>€£¥•" else "-/:;()\$&@\""
                val r3 = if (arabic) "،؟!ءأإآ" else ".,?!'"
                c.addView(row(h, r1.map { simple(it, 1f) }))
                c.addView(row(h, r2.map { simple(it, 1f) }))
                val w = 7f / r3.length
                c.addView(row(h, buildList<View> {
                    add(key(if (sym) "123" else "#+=", 1.5f, special = true, textSp = 14f) {
                        layer = if (sym) Layer.NUMBERS else Layer.SYMBOLS
                        render()
                    })
                    r3.forEach { add(simple(it, w)) }
                    add(deleteKey())
                }))
                c.addView(bottomRow(h))
            }

            Layer.EMOJI -> {
                val sv = ScrollView(this)
                sv.layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(h * 3)
                )
                sv.isVerticalScrollBarEnabled = false
                val col = LinearLayout(this)
                col.orientation = LinearLayout.VERTICAL
                EMOJI.split(" ").chunked(8).forEach { chunk ->
                    val rw = LinearLayout(this)
                    rw.orientation = LinearLayout.HORIZONTAL
                    rw.layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(46)
                    )
                    chunk.forEach { e ->
                        val tv = TextView(this)
                        tv.text = e
                        tv.gravity = Gravity.CENTER
                        tv.textSize = 26f
                        tv.layoutParams = LinearLayout.LayoutParams(
                            0, ViewGroup.LayoutParams.MATCH_PARENT, 1f
                        )
                        tv.setOnClickListener {
                            feedback(it)
                            currentInputConnection?.commitText(e, 1)
                        }
                        rw.addView(tv)
                    }
                    repeat(8 - chunk.size) { rw.addView(spacer(1f)) }
                    col.addView(rw)
                }
                sv.addView(col)
                c.addView(sv)
                c.addView(row(h, listOf(
                    key("ABC", 1.6f, special = true, textSp = 15f) {
                        layer = Layer.LETTERS
                        render()
                    },
                    spacer(5f),
                    deleteKey()
                )))
            }
        }
    }

    private fun topBar(): LinearLayout {
        val b = LinearLayout(this)
        b.orientation = LinearLayout.HORIZONTAL
        b.gravity = Gravity.CENTER_VERTICAL
        b.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(40)
        )
        b.addView(iconBtn("⚙") { openSettings() })
        b.addView(iconBtn("📋") { paste() })

        val title = TextView(this)
        val s = SpannableString("INboard")
        s.setSpan(ForegroundColorSpan(cAccent), 0, 2, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        title.text = s
        title.gravity = Gravity.CENTER
        title.textSize = 14f
        title.typeface = Typeface.DEFAULT_BOLD
        title.letterSpacing = 0.08f
        title.setTextColor(cText)
        title.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
        b.addView(title)

        b.addView(iconBtn("⌄") { requestHideSelf(0) })
        b.addView(iconBtn(if (arabic) "ع" else "EN") {
            arabic = !arabic
            shift = 0
            render()
        })
        return b
    }

    private fun iconBtn(label: String, onClick: () -> Unit): TextView {
        val tv = TextView(this)
        tv.text = label
        tv.gravity = Gravity.CENTER
        tv.textSize = 17f
        tv.setTextColor(cText)
        tv.layoutParams = LinearLayout.LayoutParams(dp(46), ViewGroup.LayoutParams.MATCH_PARENT)
        tv.setOnClickListener {
            feedback(it)
            onClick()
        }
        return tv
    }

    private fun bottomRow(h: Int): LinearLayout {
        val modeLabel = if (layer == Layer.LETTERS) "123" else "ABC"
        return row(h, listOf(
            key(modeLabel, 1.4f, special = true, textSp = 15f) {
                layer = if (layer == Layer.LETTERS) Layer.NUMBERS else Layer.LETTERS
                render()
            },
            key("😊", 1.1f, special = true, textSp = 20f) {
                layer = Layer.EMOJI
                render()
            },
            key("🌐", 1.1f, special = true, textSp = 20f) {
                arabic = !arabic
                shift = 0
                layer = Layer.LETTERS
                render()
            },
            key(if (arabic) "العربية" else "INboard", 4f, textSp = 14f) { onSpace() },
            key("⏎", 1.7f, accent = true, textSp = 22f) { onEnter() }
        ))
    }

    // ------------------------------------------------------------------ key factories

    private fun letter(ch: Char): View {
        val label = if (!arabic && shift > 0) ch.uppercaseChar().toString() else ch.toString()
        return key(label, 1f) { typeText(label) }
    }

    private fun simple(ch: Char, w: Float): View =
        key(ch.toString(), w) { typeText(ch.toString()) }

    private fun shiftKey(): View =
        key(if (shift == 2) "⇪" else "⇧", 1.5f, special = shift == 0) {
            val now = System.currentTimeMillis()
            shift = if (now - lastShiftTap < 350) 2 else if (shift == 0) 1 else 0
            lastShiftTap = now
            render()
        }

    private fun deleteKey(): View =
        key("⌫", 1.5f, special = true, repeat = true) { deleteBack() }

    private fun key(
        label: String,
        weight: Float,
        special: Boolean = false,
        accent: Boolean = false,
        repeat: Boolean = false,
        textSp: Float = 20f,
        action: () -> Unit
    ): TextView {
        val tv = TextView(this)
        tv.text = label
        tv.gravity = Gravity.CENTER
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, textSp)
        tv.setTextColor(if (accent) Color.WHITE else cText)
        tv.background = when {
            accent -> keyBg(cAccent, cAccentP)
            special -> keyBg(cSpecial, cSpecialP)
            else -> keyBg(cLetter, cLetterP)
        }
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight)
        lp.setMargins(dp(3), dp(4), dp(3), dp(4))
        tv.layoutParams = lp

        val repeater = object : Runnable {
            override fun run() {
                action()
                handler.postDelayed(this, 50)
            }
        }
        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    feedback(v)
                    action()
                    if (repeat) handler.postDelayed(repeater, 380)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    handler.removeCallbacks(repeater)
                }
            }
            true
        }
        return tv
    }

    private fun keyBg(normal: Int, pressed: Int): StateListDrawable {
        val sl = StateListDrawable()
        sl.addState(intArrayOf(android.R.attr.state_pressed), rounded(pressed))
        sl.addState(intArrayOf(), rounded(normal))
        return sl
    }

    private fun rounded(color: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = dp(10).toFloat()
        g.setColor(color)
        return g
    }

    private fun row(h: Int, views: List<View>): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(h))
        r.setPadding(dp(2), 0, dp(2), 0)
        views.forEach { r.addView(it) }
        return r
    }

    private fun spacer(w: Float): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w)
        return v
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------------ input actions

    private fun typeText(s: String) {
        val ic = currentInputConnection ?: return
        ic.commitText(s, 1)
        if (shift == 1 && layer == Layer.LETTERS) {
            shift = 0
            render()
        }
    }

    private fun deleteBack() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) {
            ic.commitText("", 1)
        } else if (!ic.deleteSurroundingTextInCodePoints(1, 0)) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
    }

    private fun onSpace() {
        val ic = currentInputConnection ?: return
        val now = System.currentTimeMillis()
        if (prefs.getBoolean("dotspace", true) && now - lastSpace < 400) {
            val before = ic.getTextBeforeCursor(2, 0)
            if (before != null && before.length == 2 && before[1] == ' ' && before[0].isLetterOrDigit()) {
                ic.deleteSurroundingText(1, 0)
                ic.commitText(". ", 1)
                lastSpace = 0L
                if (!arabic) {
                    shift = 1
                    render()
                }
                return
            }
        }
        ic.commitText(" ", 1)
        lastSpace = now
    }

    private fun onEnter() {
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        if (ei == null) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
            return
        }
        val action = ei.imeOptions and EditorInfo.IME_MASK_ACTION
        val noAction = (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (noAction || action == EditorInfo.IME_ACTION_NONE || action == EditorInfo.IME_ACTION_UNSPECIFIED) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        } else {
            ic.performEditorAction(action)
        }
    }

    private fun paste() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        if (clip != null && clip.itemCount > 0) {
            val t = clip.getItemAt(0).coerceToText(this)
            if (!t.isNullOrEmpty()) currentInputConnection?.commitText(t, 1)
        }
    }

    private fun openSettings() {
        val i = Intent(this, SettingsActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    private fun feedback(v: View) {
        if (prefs.getBoolean("haptic", true)) {
            v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        }
        if (prefs.getBoolean("sound", false)) {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD)
        }
    }

    companion object {
        private const val EMOJI =
            "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 😉 😍 🥰 😘 😋 😛 😜 🤪 😎 🤩 🥳 😏 😒 " +
                "😞 😔 😟 😕 🙁 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 " +
                "😓 🤗 🤔 🤭 🤫 🤥 😶 😐 😑 😬 🙄 😯 😴 🤤 😷 🤒 🤕 🤢 🤮 🤧 😈 👿 💀 👻 " +
                "👽 🤖 💩 👍 👎 👌 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ✋ 👏 🙌 🙏 💪 ❤️ 🧡 💛 💚 " +
                "💙 💜 🖤 💔 💯 🔥 ✨ ⭐ 🎉 🎁 🎵 ☕ 🍕 🍔 🌹 🌙 ☀️ 🚀 💻 📱 ⚡"
    }
}
