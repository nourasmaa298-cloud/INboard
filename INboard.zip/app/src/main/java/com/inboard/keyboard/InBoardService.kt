package com.inboard.keyboard

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.Locale

class InBoardService : InputMethodService(), SharedPreferences.OnSharedPreferenceChangeListener {

    private enum class Layer { LETTERS, NUMBERS, SYMBOLS, EMOJI, LANGPICK }

    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())
    private var root: LinearLayout? = null

    private var layer = Layer.LETTERS
    private var shift = 0 // 0 off, 1 once, 2 caps lock
    private var lastShiftTap = 0L
    private var lastSpace = 0L
    private var emojiCat = 1
    private var toolsOpen = false
    private var trMode = false
    private var pickMode = 0
    private var noPredict = false
    private var lastRawX = 0f

    private var sugViews: Array<TextView>? = null
    private var trView: TextView? = null
    private var trResult: String? = null
    private var trChunkRaw = ""

    private var previewPop: PopupWindow? = null
    private var altPop: PopupWindow? = null
    private var altViews: List<TextView> = emptyList()
    private var altItems: List<String> = emptyList()
    private var altSel = -1
    private var altLeft = 0

    private var bgBitmap: Bitmap? = null
    private var bgStamp = 0L
    private val downloading = HashSet<String>()

    // style
    private var dark = false
    private var cPanel = 0
    private var cLetter = 0
    private var cLetterP = 0
    private var cSpecial = 0
    private var cSpecialP = 0
    private var cText = 0
    private var cAccent = 0
    private var cAccentP = 0
    private var keyR = 10
    private var panelR = 22
    private var gap = 3
    private var txtSize = 20f
    private var bold = false
    private var border = false
    private var keyH = 52
    private var glass = true
    private var blurOn = false
    private var accentEnter = true
    private var lastShape = ""

    private val rerender = Runnable {
        render()
        applyBlur()
    }
    private val trRunnable = Runnable { doChunkTranslate() }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs.get(this)
        Predictor.init(this)
        prefs.registerOnSharedPreferenceChangeListener(this)
    }

    override fun onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(this)
        Predictor.save(this)
        super.onDestroy()
    }

    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
        if (key == "cur_lang" || key == "recent_emoji" || root == null) return
        handler.removeCallbacks(rerender)
        handler.postDelayed(rerender, 60)
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        try {
            window.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        } catch (_: Throwable) {
        }
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.layoutDirection = View.LAYOUT_DIRECTION_LTR
        root = c
        safe { render() }
        return c
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val t = info?.inputType ?: 0
        val cls = t and InputType.TYPE_MASK_CLASS
        val v = t and InputType.TYPE_MASK_VARIATION
        layer = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE ||
            cls == InputType.TYPE_CLASS_DATETIME
        ) Layer.NUMBERS else Layer.LETTERS
        val pwd = cls == InputType.TYPE_CLASS_TEXT && (v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD || v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)
        val noLearn = ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING) != 0
        noPredict = pwd || noLearn
        toolsOpen = false
        val lang = curLang()
        var caps = 0
        if (info != null && t != 0) caps = currentInputConnection?.getCursorCapsMode(t) ?: 0
        shift = if (lang.cased && pb("autocap", true) && caps != 0) 1 else 0
        render()
        applyBlur()
        Predictor.warm(this, lang.dict)
        autoDownload(lang.dict)
    }

    override fun onFinishInput() {
        super.onFinishInput()
        Predictor.save(this)
    }

    override fun onWindowHidden() {
        super.onWindowHidden()
        dismissPopups()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        if (layer == Layer.LETTERS) updateSuggestions()
    }

    private fun autoDownload(code: String) {
        if (code.isEmpty() || !pb("auto_dl", true)) return
        if (Predictor.hasDict(this, code)) return
        if (!downloading.add(code)) return
        Predictor.download(this, code) { _ ->
            downloading.remove(code)
        }
    }

    // ------------------------------------------------------------------ prefs helpers

    private fun pi(k: String, d: Int): Int = prefs.getInt(k, d)
    private fun pb(k: String, d: Boolean): Boolean = prefs.getBoolean(k, d)
    private fun ps(k: String, d: String): String = prefs.getString(k, d) ?: d

    private fun t(en: String, ar: String): String =
        if (Locale.getDefault().language == "ar") ar else en

    private fun enabledLangs(): List<Lang> {
        val codes = ps("langs", "en,ar")
        val l = codes.split(",").mapNotNull { Langs.byCode(it.trim()) }
        return if (l.isEmpty()) listOf(Langs.all[0]) else l
    }

    private fun curLang(): Lang {
        val l = enabledLangs()
        val c = ps("cur_lang", l[0].code)
        return l.firstOrNull { it.code == c } ?: l[0]
    }

    // ------------------------------------------------------------------ style

    private fun mix(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) * (1 - t) + Color.red(b) * t).toInt()
        val g = (Color.green(a) * (1 - t) + Color.green(b) * t).toInt()
        val bl = (Color.blue(a) * (1 - t) + Color.blue(b) * t).toInt()
        return Color.rgb(r, g, bl)
    }

    private fun alpha(c: Int, pct: Int): Int =
        (c and 0x00FFFFFF) or ((255 * pct.coerceIn(0, 100) / 100) shl 24)

    private fun loadStyle() {
        val sysDark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val th = Themes.resolve(pi("preset", 0), sysDark)
        dark = th.dark
        val ov = pi("accent", 0)
        cAccent = if (ov != 0) ov else th.accent
        cAccentP = mix(cAccent, Color.BLACK, 0.25f)
        cText = th.text
        val ko = pi("key_alpha", 92)
        val po = pi("panel_alpha", 82)
        cPanel = alpha(th.panel, po)
        cLetter = alpha(th.letter, ko)
        cSpecial = alpha(th.special, ko)
        val pl = if (dark) mix(th.letter, Color.WHITE, 0.25f) else mix(th.letter, Color.BLACK, 0.12f)
        val ps2 = if (dark) mix(th.special, Color.WHITE, 0.2f) else mix(th.special, Color.WHITE, 0.6f)
        cLetterP = alpha(pl, minOf(100, ko + 8))
        cSpecialP = alpha(ps2, minOf(100, ko + 8))
        keyR = pi("key_r", 10)
        panelR = pi("panel_r", 22)
        gap = pi("gap", 3)
        txtSize = pi("txt", 20).toFloat()
        bold = pb("bold", false)
        border = pb("border", false)
        keyH = pi("key_h", 52)

        glass = pi("style", 0) == 0
        blurOn = pb("blur", true) && blurSupported()
        accentEnter = !glass || pb("enter_accent", false)
        if (glass) {
            var pa = pi("g_panel_alpha", 55)
            if (!blurOn) pa = maxOf(pa, 88)
            val ka = pi("g_key_alpha", 55)
            cPanel = alpha(th.panel, pa)
            cLetter = alpha(th.letter, ka)
            cSpecial = alpha(th.special, ka)
            cLetterP = alpha(mix(th.letter, Color.WHITE, 0.35f), minOf(100, ka + 25))
            cSpecialP = alpha(mix(th.special, Color.WHITE, 0.3f), minOf(100, ka + 25))
        }
    }

    private fun blurSupported(): Boolean {
        if (Build.VERSION.SDK_INT < 31) return false
        return try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm.isCrossWindowBlurEnabled
        } catch (_: Throwable) {
            false
        }
    }

    private fun safe(block: () -> Unit) {
        try {
            block()
        } catch (e: Throwable) {
            android.util.Log.e("INboard", "error", e)
        }
    }

    /** Makes the window (and therefore the blur region) follow the rounded panel shape. */
    private fun applyWindowShape() {
        val r = if (glass) dp(pi("g_radius", 30)).toFloat() else dp(panelR).toFloat()
        val radii = if (glass) floatArrayOf(r, r, r, r, r, r, r, r) else floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        val key = glass.toString() + r.toString()
        if (key == lastShape) return
        try {
            val w = window.window ?: return
            val g = GradientDrawable()
            g.setColor(Color.TRANSPARENT)
            g.cornerRadii = radii
            w.setBackgroundDrawable(g)
            lastShape = key
        } catch (_: Throwable) {
        }
    }

    private fun loadBg(): Bitmap? {
        if (!pb("bg_img", false)) {
            bgBitmap = null
            return null
        }
        val f = File(filesDir, "bg.jpg")
        if (!f.exists()) return null
        if (bgBitmap == null || f.lastModified() != bgStamp) {
            try {
                bgBitmap = BitmapFactory.decodeFile(f.absolutePath)
                bgStamp = f.lastModified()
            } catch (_: Throwable) {
                bgBitmap = null
            }
        }
        return bgBitmap
    }

    /** Blurs only what is behind the keyboard window (not the whole screen). */
    private fun applyBlur() {
        if (Build.VERSION.SDK_INT < 31) return
        try {
            val w = window.window ?: return
            w.clearFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
            if (blurOn) {
                w.setBackgroundBlurRadius(pi("blur_r", 80))
            } else {
                w.setBackgroundBlurRadius(0)
            }
        } catch (_: Throwable) {
        }
    }

    // ------------------------------------------------------------------ rendering

    private fun render() {
        try {
            renderInternal()
        } catch (e: Throwable) {
            android.util.Log.e("INboard", "render failed", e)
            layer = Layer.LETTERS
            trMode = false
            toolsOpen = false
            try {
                renderInternal()
            } catch (e2: Throwable) {
                android.util.Log.e("INboard", "render failed again", e2)
            }
        }
    }

    private fun renderInternal() {
        val c = root ?: return
        dismissPopups()
        loadStyle()
        applyWindowShape()
        c.removeAllViews()
        val dens = resources.displayMetrics.density
        var padL = 0
        var padR = 0
        val oh = pi("onehand", 0)
        val extra = (resources.displayMetrics.widthPixels * 0.2f).toInt()
        if (oh == 1) padR = extra else if (oh == 2) padL = extra
        if (glass) {
            c.background = GlassPanelDrawable(
                cPanel, dp(pi("g_radius", 30)).toFloat(), pi("g_edge", 65), pi("g_gloss", 55),
                dark, loadBg(), pi("bg_dim", 35), dens
            )
            c.setPadding(dp(8) + padL, dp(8), dp(8) + padR, dp(6))
        } else {
            c.background = PanelDrawable(cPanel, loadBg(), pi("bg_dim", 35), dp(panelR).toFloat())
            c.setPadding(dp(4) + padL, dp(2), dp(4) + padR, dp(8))
        }
        c.addView(toolbar())
        val lang = curLang()
        val h = if (layer == Layer.LETTERS && lang.rows.size > 3) (keyH * 0.8f).toInt() else keyH

        when (layer) {
            Layer.LETTERS -> {
                if (pb("numrow", false)) {
                    c.addView(row((h * 0.8f).toInt(), "1234567890".map { simple(digit(it), 1f) }))
                }
                val rows = lang.rows
                val maxLen = rows.maxOf { it.length }
                rows.forEachIndexed { idx, r ->
                    val last = idx == rows.size - 1
                    val views = ArrayList<View>()
                    var used = r.length.toFloat()
                    if (last && lang.cased) used += 3f else if (last) used += 1.5f
                    val pad = (maxLen - used) / 2f
                    if (pad > 0.05f) views.add(spacer(pad))
                    if (last && lang.cased) views.add(shiftKey())
                    r.forEach { views.add(letter(it, lang)) }
                    if (last) views.add(deleteKey())
                    if (pad > 0.05f) views.add(spacer(pad))
                    c.addView(row(h, views))
                }
                addBottom(c, h, lang)
            }

            Layer.NUMBERS, Layer.SYMBOLS -> {
                val sym = layer == Layer.SYMBOLS
                val r1 = if (sym) "[]{}#%^*+=" else "1234567890"
                val r2 = if (sym) "_\\|~<>€£¥•" else "-/:;()\$&@\""
                val rtl = isRtl(lang)
                val r3 = if (rtl) "،؟!ءأإآ" else ".,?!'"
                c.addView(row(h, r1.map { simple(if (sym) it.toString() else digit(it), 1f) }))
                c.addView(row(h, r2.map { simple(it.toString(), 1f) }))
                val w = 7f / r3.length
                val views = ArrayList<View>()
                views.add(key(label = if (sym) "123" else "#+=", weight = 1.5f, kind = 1, textSp = 14f) {
                    layer = if (sym) Layer.NUMBERS else Layer.SYMBOLS
                    render()
                })
                r3.forEach { views.add(simple(it.toString(), w)) }
                views.add(deleteKey())
                c.addView(row(h, views))
                addBottom(c, h, lang)
            }

            Layer.EMOJI -> {
                val items: List<String> = if (emojiCat == 0) recentEmoji() else Emojis.list(emojiCat)
                val grid = GridView(this)
                grid.numColumns = 8
                grid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
                grid.selector = ColorDrawable(Color.TRANSPARENT)
                grid.isVerticalScrollBarEnabled = false
                grid.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(h * 3))
                grid.adapter = GridAdapter(items, 26f, 44, -1)
                grid.setOnItemClickListener { _, v, pos, _ ->
                    feedback(v)
                    commitEmoji(items[pos])
                }
                c.addView(grid)
                c.addView(emojiBar(h))
            }

            Layer.LANGPICK -> {
                val list = if (pickMode == 0) TrLangs.list else TrLangs.list.filter { it.first != "auto" }
                val curCode = if (pickMode == 0) ps("tr_src", "en") else ps("tr_tgt", "ar")
                val names = list.map { it.second }
                val grid = GridView(this)
                grid.numColumns = 3
                grid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
                grid.selector = ColorDrawable(Color.TRANSPARENT)
                grid.isVerticalScrollBarEnabled = false
                grid.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(h * 3))
                grid.adapter = GridAdapter(names, 15f, 44, list.indexOfFirst { it.first == curCode })
                grid.setOnItemClickListener { _, v, pos, _ ->
                    feedback(v)
                    val code = list[pos].first
                    if (pickMode == 0) {
                        prefs.edit().putString("tr_src", code).apply()
                        val l = enabledLangs().firstOrNull { it.code == code }
                        if (l != null) prefs.edit().putString("cur_lang", l.code).apply()
                    } else {
                        prefs.edit().putString("tr_tgt", code).apply()
                    }
                    layer = Layer.LETTERS
                    render()
                }
                c.addView(grid)
                c.addView(row(h, listOf(
                    key(label = "ABC", weight = 1.5f, kind = 1, textSp = 15f) {
                        layer = Layer.LETTERS
                        render()
                    },
                    spacer(7f)
                )))
            }
        }
        updateSuggestions()
    }

    private fun isRtl(l: Lang): Boolean = l.rtl

    private fun digit(c: Char): String {
        if (pi("digits", 0) == 1 && c in '0'..'9') return (0x0660 + (c - '0')).toChar().toString()
        return c.toString()
    }

    // ------------------------------------------------------------------ toolbar

    private fun toolbar(): LinearLayout {
        val b = LinearLayout(this)
        b.orientation = LinearLayout.HORIZONTAL
        b.gravity = Gravity.CENTER_VERTICAL
        b.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42))
        sugViews = null
        trView = null

        if (trMode) {
            b.addView(iconBtn(IconDrawable.Type.TRANSLATE, dp(44), cAccent) {
                trMode = false
                render()
            })
            b.addView(chip(ps("tr_src", "en").uppercase()) {
                pickMode = 0
                layer = Layer.LANGPICK
                render()
            })
            b.addView(iconBtn(IconDrawable.Type.SWAP, dp(34), cText) {
                val s = ps("tr_src", "en")
                val g = ps("tr_tgt", "ar")
                if (s != "auto") {
                    prefs.edit().putString("tr_src", g).putString("tr_tgt", s).apply()
                    render()
                }
            })
            b.addView(chip(ps("tr_tgt", "ar").uppercase()) {
                pickMode = 1
                layer = Layer.LANGPICK
                render()
            })
            val tv = TextView(this)
            tv.gravity = Gravity.CENTER_VERTICAL
            tv.setPadding(dp(10), 0, dp(10), 0)
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            tv.setTextColor(cText)
            tv.maxLines = 1
            tv.ellipsize = android.text.TextUtils.TruncateAt.END
            tv.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            tv.setOnClickListener { applyTranslation() }
            b.addView(tv)
            trView = tv
        } else if (toolsOpen) {
            toolBtn(b, IconDrawable.Type.CLOSE) {
                toolsOpen = false
                render()
            }
            toolBtn(b, IconDrawable.Type.GEAR) { openSettings() }
            toolBtn(b, IconDrawable.Type.CLIPBOARD) { paste() }
            toolBtn(b, IconDrawable.Type.TRANSLATE) {
                trMode = true
                toolsOpen = false
                render()
            }
            toolBtn(b, IconDrawable.Type.PALETTE) {
                prefs.edit().putInt("preset", (pi("preset", 0) + 1) % Themes.list.size).apply()
            }
            toolBtn(b, IconDrawable.Type.HAND) {
                prefs.edit().putInt("onehand", (pi("onehand", 0) + 1) % 3).apply()
            }
            toolBtn(b, IconDrawable.Type.CHEVRON_DOWN) { requestHideSelf(0) }
        } else {
            b.addView(iconBtn(IconDrawable.Type.GRID, dp(44), cText) {
                toolsOpen = true
                render()
            })
            val arr = Array(3) { TextView(this) }
            for (i in 0 until 3) {
                val tv = arr[i]
                tv.gravity = Gravity.CENTER
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                tv.setTextColor(cText)
                tv.maxLines = 1
                tv.ellipsize = android.text.TextUtils.TruncateAt.END
                if (i == 0) tv.typeface = Typeface.DEFAULT_BOLD
                tv.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                tv.setOnClickListener { v ->
                    val s = v.tag as? String
                    if (!s.isNullOrEmpty()) applySuggestion(s)
                }
                b.addView(tv)
                if (i < 2) {
                    val d = View(this)
                    d.setBackgroundColor(alpha(cText, 20))
                    d.layoutParams = LinearLayout.LayoutParams(dp(1), dp(20))
                    b.addView(d)
                }
            }
            sugViews = arr
        }
        if (glass) {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38))
            lp.setMargins(dp(2), 0, dp(2), dp(6))
            b.layoutParams = lp
            b.setPadding(dp(6), 0, dp(6), 0)
            b.background = glassPill()
        }
        return b
    }

    private fun glassKey(kind: Int): GlassKeyDrawable {
        val n: Int
        val p: Int
        if (kind == 2 && accentEnter) {
            n = alpha(cAccent, 88)
            p = alpha(cAccentP, 96)
        } else if (kind == 1 || kind == 2) {
            n = cSpecial
            p = cSpecialP
        } else {
            n = cLetter
            p = cLetterP
        }
        return GlassKeyDrawable(
            n, p, dp(keyR).toFloat(), pi("g_edge", 65), pi("g_gloss", 55), dark,
            pb("g_glow", true), dp(1).toFloat(), resources.displayMetrics.density
        )
    }

    private fun glassPill(): GlassKeyDrawable {
        val f = alpha(Color.WHITE, if (dark) 12 else 48)
        return GlassKeyDrawable(
            f, f, 4000f, pi("g_edge", 65), pi("g_gloss", 55), dark,
            false, 0f, resources.displayMetrics.density
        )
    }

    private fun toolBtn(bar: LinearLayout, type: IconDrawable.Type, onClick: () -> Unit) {
        val v = iconBtn(type, 0, cText, onClick)
        v.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
        bar.addView(v)
    }

    private fun chip(text: String, onClick: () -> Unit): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.gravity = Gravity.CENTER
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setTextColor(cText)
        tv.background = shape(cLetter, dp(10).toFloat())
        val lp = LinearLayout.LayoutParams(dp(46), dp(30))
        lp.setMargins(dp(2), 0, dp(2), 0)
        tv.layoutParams = lp
        tv.setOnClickListener {
            feedback(it)
            onClick()
        }
        return tv
    }

    private fun iconBtn(type: IconDrawable.Type, widthPx: Int, tint: Int, onClick: () -> Unit): FrameLayout {
        val f = FrameLayout(this)
        val iv = ImageView(this)
        iv.setImageDrawable(IconDrawable(type, tint))
        iv.layoutParams = FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER)
        f.addView(iv)
        f.layoutParams = LinearLayout.LayoutParams(widthPx, ViewGroup.LayoutParams.MATCH_PARENT)
        f.setOnClickListener {
            feedback(it)
            onClick()
        }
        return f
    }

    private fun bottomRow(h: Int, lang: Lang): LinearLayout {
        val rtl = isRtl(lang)
        val comma = if (rtl) "،" else ","
        val commaAlts = if (rtl) listOf(",", "؛", "؟", "!", ":", "\"") else listOf("?", "!", ";", ":", "'", "\"")
        val ei = currentInputEditorInfo
        val act = if (ei == null) 0 else (ei.imeOptions and EditorInfo.IME_MASK_ACTION)
        val enterIcon = when (act) {
            EditorInfo.IME_ACTION_SEARCH -> IconDrawable.Type.SEARCH
            EditorInfo.IME_ACTION_SEND -> IconDrawable.Type.SEND
            EditorInfo.IME_ACTION_GO, EditorInfo.IME_ACTION_NEXT -> IconDrawable.Type.GO
            EditorInfo.IME_ACTION_DONE -> IconDrawable.Type.CHECK
            else -> IconDrawable.Type.RETURN
        }
        val views = ArrayList<View>()
        views.add(key(label = if (layer == Layer.LETTERS) "123" else "ABC", weight = 1.3f, kind = 1, textSp = 15f) {
            layer = if (layer == Layer.LETTERS) Layer.NUMBERS else Layer.LETTERS
            render()
        })
        views.add(key(icon = IconDrawable.Type.SMILEY, weight = 1f, kind = 1) {
            layer = Layer.EMOJI
            if (emojiCat == 0 && recentEmoji().isEmpty()) emojiCat = 1
            render()
        })
        val bar = glass && pb("bottom_bar", true)
        if (!bar) {
            views.add(key(icon = IconDrawable.Type.GLOBE, weight = 1f, kind = 1, onLong = { showImePicker() }) { nextLang() })
            views.add(key(label = comma, weight = 0.8f, alts = commaAlts) { typeText(comma) })
        }
        val spaceW = if (bar) 5.4f else 3.4f
        if (pi("space_style", 0) == 0) {
            views.add(key(weight = spaceW, swipe = true, corner = lang.code.uppercase(), onLong = { showImePicker() }) { onSpace() })
        } else {
            views.add(key(label = lang.name, weight = spaceW, textSp = 14f, swipe = true, onLong = { showImePicker() }) { onSpace() })
        }
        if (!bar) {
            views.add(key(label = ".", weight = 0.8f, alts = listOf("…", "!", "?")) { typeText(".") })
        }
        views.add(key(icon = enterIcon, weight = 1.5f, kind = 2) { onEnter() })
        return row(h, views)
    }

    private fun addBottom(c: LinearLayout, h: Int, lang: Lang) {
        c.addView(bottomRow(h, lang))
        if (glass && pb("bottom_bar", true)) c.addView(bottomBar())
    }

    private fun bottomBar(): LinearLayout {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38))
        bar.setPadding(dp(10), 0, dp(10), 0)
        bar.addView(barIcon(IconDrawable.Type.GLOBE, { showImePicker() }) { nextLang() })
        bar.addView(spacer(1f))
        bar.addView(barIcon(IconDrawable.Type.MIC, null) { startVoice() })
        return bar
    }

    private fun barIcon(type: IconDrawable.Type, onLong: (() -> Unit)?, onClick: () -> Unit): FrameLayout {
        val f = FrameLayout(this)
        val iv = ImageView(this)
        iv.setImageDrawable(IconDrawable(type, alpha(cText, 92)))
        iv.layoutParams = FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER)
        f.addView(iv)
        f.layoutParams = LinearLayout.LayoutParams(dp(52), ViewGroup.LayoutParams.MATCH_PARENT)
        f.setOnClickListener {
            feedback(it)
            safe { onClick() }
        }
        if (onLong != null) {
            f.setOnLongClickListener {
                safe { onLong() }
                true
            }
        }
        return f
    }

    private fun startVoice() {
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            for (imi in imm.enabledInputMethodList) {
                for (st in imm.getEnabledInputMethodSubtypeList(imi, true)) {
                    if (st.mode == "voice") {
                        if (Build.VERSION.SDK_INT >= 28) {
                            switchInputMethod(imi.id, st)
                        } else {
                            val tok = window.window?.attributes?.token
                            if (tok != null) imm.setInputMethodAndSubtype(tok, imi.id, st)
                        }
                        return
                    }
                }
            }
        } catch (_: Throwable) {
        }
        Toast.makeText(
            this,
            t("Voice typing is not available on this phone", "الكتابة الصوتية غير متوفرة على هذا الهاتف"),
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun emojiBar(h: Int): LinearLayout {
        val views = ArrayList<View>()
        views.add(key(label = "ABC", weight = 1.3f, kind = 1, textSp = 15f) {
            layer = Layer.LETTERS
            render()
        })
        for (i in Emojis.cats.indices) {
            val f = FrameLayout(this)
            val iv = ImageView(this)
            iv.setImageDrawable(IconDrawable(Emojis.cats[i].icon, if (i == emojiCat) cAccent else cText))
            iv.layoutParams = FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER)
            f.addView(iv)
            f.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            f.setOnClickListener {
                feedback(it)
                emojiCat = i
                render()
            }
            views.add(f)
        }
        views.add(deleteKey())
        return row(h, views)
    }

    // ------------------------------------------------------------------ key factories

    private fun letter(ch: Char, lang: Lang): View {
        val up = lang.cased && shift > 0
        val loc = Locale(lang.code)
        val label = if (up) ch.toString().uppercase(loc) else ch.toString()
        val alts = Langs.alts(lang, ch)?.map { a -> if (up) a.toString().uppercase(loc) else a.toString() }
        return key(label = label, alts = alts, preview = true) { typeText(label) }
    }

    private fun simple(s: String, w: Float): View = key(label = s, weight = w, preview = true) { typeText(s) }

    private fun shiftKey(): View {
        val ic = when (shift) {
            0 -> IconDrawable.Type.SHIFT
            1 -> IconDrawable.Type.SHIFT_ON
            else -> IconDrawable.Type.SHIFT_LOCK
        }
        return key(icon = ic, weight = 1.5f, kind = if (shift == 0) 1 else 0) {
            val now = System.currentTimeMillis()
            shift = if (now - lastShiftTap < 350) 2 else if (shift == 0) 1 else 0
            lastShiftTap = now
            render()
        }
    }

    private fun deleteKey(): View =
        key(icon = IconDrawable.Type.BACKSPACE, weight = 1.5f, kind = 1, rep = true) { deleteBack() }

    private fun key(
        label: String? = null,
        icon: IconDrawable.Type? = null,
        weight: Float = 1f,
        kind: Int = 0,
        rep: Boolean = false,
        alts: List<String>? = null,
        textSp: Float = 0f,
        preview: Boolean = false,
        swipe: Boolean = false,
        onLong: (() -> Unit)? = null,
        corner: String? = null,
        action: () -> Unit
    ): View {
        val fl = FrameLayout(this)
        val gk: GlassKeyDrawable? = if (glass) glassKey(kind) else null
        fl.background = gk ?: keyBg(kind, dp(keyR).toFloat())
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight)
        lp.setMargins(dp(gap), dp(gap + 1), dp(gap), dp(gap + 1))
        fl.layoutParams = lp
        val tint = if (kind == 2 && accentEnter) Color.WHITE else cText
        if (icon != null) {
            val iv = ImageView(this)
            iv.setImageDrawable(IconDrawable(icon, tint))
            iv.layoutParams = FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER)
            fl.addView(iv)
        } else if (label != null) {
            val tv = TextView(this)
            tv.text = label
            tv.gravity = Gravity.CENTER
            tv.setTextColor(tint)
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, if (textSp > 0f) textSp else txtSize)
            if (bold) tv.typeface = Typeface.DEFAULT_BOLD
            tv.maxLines = 1
            tv.layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            fl.addView(tv)
        }
        if (corner != null) {
            val ct = TextView(this)
            ct.text = corner
            ct.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            ct.setTextColor(alpha(cText, 60))
            ct.typeface = Typeface.DEFAULT_BOLD
            ct.letterSpacing = 0.08f
            val clp = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.END
            )
            clp.setMargins(0, 0, dp(10), dp(6))
            ct.layoutParams = clp
            fl.addView(ct)
        }

        val act: () -> Unit = { safe { action() } }
        val hasAlts = alts != null && alts.isNotEmpty()
        val deferred = hasAlts || onLong != null || swipe
        var longFired = false
        var moved = false
        var lastX = 0f
        val repeater = object : Runnable {
            override fun run() {
                act()
                handler.postDelayed(this, 50)
            }
        }
        val longRun = Runnable {
            longFired = true
            safe {
                if (hasAlts && alts != null) showAlts(fl, alts) else onLong?.invoke()
            }
        }
        fl.setOnTouchListener { v, e ->
            lastRawX = e.rawX
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    gk?.setPress(true, e.x, e.y)
                    longFired = false
                    moved = false
                    lastX = e.rawX
                    feedback(v)
                    if (preview && label != null) showPreview(v, label)
                    if (!deferred) {
                        act()
                        if (rep) handler.postDelayed(repeater, 380)
                    } else if (hasAlts || onLong != null) {
                        handler.postDelayed(longRun, pi("long_ms", 350).toLong())
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    gk?.setPress(true, e.x, e.y)
                    if (altPop != null) {
                        altSelectAt(e.rawX)
                    } else if (swipe && pb("space_swipe", true)) {
                        val step = dp(14).toFloat()
                        val dx = e.rawX - lastX
                        if (Math.abs(dx) >= step) {
                            moved = true
                            handler.removeCallbacks(longRun)
                            val n = (dx / step).toInt()
                            val code = if (n > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
                            for (i in 0 until Math.abs(n)) sendDownUpKeyEvents(code)
                            lastX += n * step
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longRun)
                    handler.removeCallbacks(repeater)
                    v.isPressed = false
                    gk?.setPress(false, 0f, 0f)
                    hidePreview()
                    if (altPop != null) {
                        commitAlt()
                    } else if (deferred && !longFired && !moved) {
                        act()
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longRun)
                    handler.removeCallbacks(repeater)
                    v.isPressed = false
                    gk?.setPress(false, 0f, 0f)
                    hidePreview()
                    dismissAlts()
                }
            }
            true
        }
        return fl
    }

    private fun shape(color: Int, r: Float): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = r
        g.setColor(color)
        if (border) g.setStroke(dp(1), alpha(cText, 18))
        return g
    }

    private fun keyBg(kind: Int, r: Float): StateListDrawable {
        val n = when (kind) {
            2 -> cAccent
            1 -> cSpecial
            else -> cLetter
        }
        val p = when (kind) {
            2 -> cAccentP
            1 -> cSpecialP
            else -> cLetterP
        }
        val sl = StateListDrawable()
        sl.addState(intArrayOf(android.R.attr.state_pressed), shape(p, r))
        sl.addState(intArrayOf(), shape(n, r))
        return sl
    }

    private fun row(h: Int, views: List<View>): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(h))
        r.setPadding(dp(2), 0, dp(2), 0)
        for (v in views) r.addView(v)
        return r
    }

    private fun spacer(w: Float): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w)
        return v
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------------ popups

    private fun showPreview(v: View, text: String) {
        if (!pb("preview", true)) return
        hidePreview()
        val tv = TextView(this)
        tv.text = text
        tv.gravity = Gravity.CENTER
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28f)
        tv.setTextColor(if (dark) Color.WHITE else 0xFF111111.toInt())
        val g = GradientDrawable()
        g.cornerRadius = dp(12).toFloat()
        g.setColor(if (dark) 0xFF5A5A5E.toInt() else Color.WHITE)
        g.setStroke(dp(1), alpha(Color.BLACK, 15))
        tv.background = g
        val w = v.width + dp(14)
        val hh = dp(58)
        val pw = PopupWindow(tv, w, hh, false)
        pw.isClippingEnabled = false
        pw.isTouchable = false
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        try {
            pw.showAtLocation(v, Gravity.NO_GRAVITY, loc[0] - dp(7), loc[1] - hh - dp(4))
            previewPop = pw
        } catch (_: Throwable) {
        }
    }

    private fun hidePreview() {
        try {
            previewPop?.dismiss()
        } catch (_: Throwable) {
        }
        previewPop = null
    }

    private fun showAlts(anchor: View, alts: List<String>) {
        hidePreview()
        dismissAlts()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.setPadding(dp(4), dp(4), dp(4), dp(4))
        val g = GradientDrawable()
        g.cornerRadius = dp(14).toFloat()
        g.setColor(if (dark) 0xFF3A3A3E.toInt() else Color.WHITE)
        g.setStroke(dp(1), alpha(Color.BLACK, 15))
        box.background = g
        val views = ArrayList<TextView>()
        for (a in alts) {
            val tv = TextView(this)
            tv.text = a
            tv.gravity = Gravity.CENTER
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            tv.setTextColor(if (dark) Color.WHITE else 0xFF111111.toInt())
            tv.layoutParams = LinearLayout.LayoutParams(dp(40), dp(48))
            box.addView(tv)
            views.add(tv)
        }
        val totalW = alts.size * dp(40) + dp(8)
        val hh = dp(56)
        val loc = IntArray(2)
        anchor.getLocationOnScreen(loc)
        val sw = resources.displayMetrics.widthPixels
        var x = loc[0] + anchor.width / 2 - totalW / 2
        if (x < 0) x = 0
        if (x > sw - totalW) x = sw - totalW
        val pw = PopupWindow(box, totalW, hh, false)
        pw.isClippingEnabled = false
        pw.isTouchable = false
        try {
            pw.showAtLocation(anchor, Gravity.NO_GRAVITY, x, loc[1] - hh - dp(6))
        } catch (_: Throwable) {
            return
        }
        altPop = pw
        altViews = views
        altItems = alts
        altLeft = x
        altSel = -1
        altSelectAt(lastRawX)
    }

    private fun altSelectAt(rawX: Float) {
        if (altItems.isEmpty()) return
        val idx = ((rawX - altLeft - dp(4)) / dp(40)).toInt().coerceIn(0, altItems.size - 1)
        if (idx == altSel) return
        altSel = idx
        for (i in altViews.indices) {
            if (i == idx) altViews[i].background = shape(cAccent, dp(10).toFloat()) else altViews[i].background = null
            altViews[i].setTextColor(if (i == idx) Color.WHITE else (if (dark) Color.WHITE else 0xFF111111.toInt()))
        }
    }

    private fun commitAlt() {
        val s = altItems.getOrNull(altSel)
        dismissAlts()
        if (s != null) typeText(s)
    }

    private fun dismissAlts() {
        try {
            altPop?.dismiss()
        } catch (_: Throwable) {
        }
        altPop = null
        altSel = -1
        altItems = emptyList()
        altViews = emptyList()
    }

    private fun dismissPopups() {
        hidePreview()
        dismissAlts()
    }

    // ------------------------------------------------------------------ grid adapter (emoji / language list)

    private inner class GridAdapter(
        val items: List<String>,
        val sp: Float,
        val rowDp: Int,
        val selected: Int
    ) : BaseAdapter() {
        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val tv = (convertView as? TextView) ?: TextView(this@InBoardService)
            tv.text = items[position]
            tv.gravity = Gravity.CENTER
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            tv.maxLines = 1
            tv.layoutParams = android.widget.AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(rowDp))
            if (position == selected) {
                tv.setTextColor(Color.WHITE)
                tv.background = shape(cAccent, dp(10).toFloat())
            } else {
                tv.setTextColor(cText)
                tv.background = null
            }
            return tv
        }
    }

    // ------------------------------------------------------------------ text helpers

    private fun wordOf(before: String): String {
        var i = before.length
        while (i > 0 && isWordChar(before[i - 1])) i--
        return before.substring(i)
    }

    private fun prevOf(before: String, w: String): String {
        val rest = before.substring(0, before.length - w.length)
        if (rest.isEmpty() || !rest.last().isWhitespace()) return ""
        val tt = rest.trimEnd()
        var j = tt.length
        while (j > 0 && isWordChar(tt[j - 1])) j--
        return tt.substring(j).lowercase()
    }

    private fun beforeText(): String =
        currentInputConnection?.getTextBeforeCursor(60, 0)?.toString() ?: ""

    // ------------------------------------------------------------------ input actions

    private fun typeText(s: String) {
        val ic = currentInputConnection ?: return
        if (s.isNotEmpty() && !isWordChar(s[0])) finalizeWord(false)
        ic.commitText(s, 1)
        if (shift == 1 && layer == Layer.LETTERS) {
            shift = 0
            render()
        } else {
            updateSuggestions()
        }
        autoCap()
    }

    private fun autoCap() {
        if (!pb("autocap", true) || shift != 0 || layer != Layer.LETTERS) return
        if (!curLang().cased) return
        val ei = currentInputEditorInfo ?: return
        if (ei.inputType == 0) return
        val caps = currentInputConnection?.getCursorCapsMode(ei.inputType) ?: 0
        if (caps != 0) {
            shift = 1
            render()
        }
    }

    private fun deleteBack() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) {
            ic.commitText("", 1)
        } else if (!ic.deleteSurroundingTextInCodePoints(1, 0)) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
        updateSuggestions()
    }

    /** Learns (and optionally auto-corrects) the word before the cursor. Returns the final word. */
    private fun finalizeWord(allowCorrect: Boolean): String {
        val ic = currentInputConnection ?: return ""
        val before = beforeText()
        val w = wordOf(before)
        if (w.isEmpty()) return ""
        var result = w
        val prev = prevOf(before, w)
        if (allowCorrect && pb("autocorrect", false) && !noPredict && !trMode) {
            val fix = Predictor.correct(curLang().dict, w)
            if (fix != null) {
                ic.deleteSurroundingText(w.length, 0)
                ic.commitText(fix, 1)
                result = fix
            }
        }
        return result
    }

    private fun onSpace() {
        val ic = currentInputConnection ?: return
        val now = System.currentTimeMillis()
        if (pb("dotspace", true) && now - lastSpace < 400) {
            val before = ic.getTextBeforeCursor(2, 0)
            if (before != null && before.length == 2 && before[1] == ' ' && before[0].isLetterOrDigit()) {
                ic.deleteSurroundingText(1, 0)
                ic.commitText(". ", 1)
                lastSpace = 0L
                updateSuggestions()
                autoCap()
                return
            }
        }
        val w = finalizeWord(true)
        ic.commitText(" ", 1)
        lastSpace = now
        if (trMode && pb("tr_auto", true) && w.isNotEmpty()) autoTranslate(w)
        updateSuggestions()
        autoCap()
    }

    private fun onEnter() {
        val ic = currentInputConnection ?: return
        finalizeWord(false)
        val ei = currentInputEditorInfo
        if (ei == null) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        } else {
            val action = ei.imeOptions and EditorInfo.IME_MASK_ACTION
            val noAction = (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
            if (noAction || action == EditorInfo.IME_ACTION_NONE || action == EditorInfo.IME_ACTION_UNSPECIFIED) {
                sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
            } else {
                ic.performEditorAction(action)
            }
        }
        updateSuggestions()
        autoCap()
    }

    private fun nextLang() {
        val l = enabledLangs()
        if (l.size <= 1) {
            showImePicker()
            return
        }
        val cur = curLang()
        val i = l.indexOfFirst { it.code == cur.code }
        val n = l[(i + 1) % l.size]
        prefs.edit().putString("cur_lang", n.code).apply()
        shift = 0
        layer = Layer.LETTERS
        render()
        Predictor.warm(this, n.dict)
        autoDownload(n.dict)
    }

    private fun showImePicker() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showInputMethodPicker()
    }

    private fun paste() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        if (clip != null && clip.itemCount > 0) {
            val tx = clip.getItemAt(0).coerceToText(this)
            if (!tx.isNullOrEmpty()) currentInputConnection?.commitText(tx, 1)
        }
    }

    private fun openSettings() {
        val i = Intent(this, SettingsActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    // ------------------------------------------------------------------ emoji

    private fun recentEmoji(): List<String> {
        val s = ps("recent_emoji", "")
        return if (s.isEmpty()) emptyList() else s.split(" ").filter { it.isNotEmpty() }
    }

    private fun commitEmoji(e: String) {
        currentInputConnection?.commitText(e, 1)
        val l = recentEmoji().toMutableList()
        l.remove(e)
        l.add(0, e)
        prefs.edit().putString("recent_emoji", l.take(40).joinToString(" ")).apply()
    }

    // ------------------------------------------------------------------ suggestions

    private fun updateSuggestions() {
        if (trMode) {
            scheduleTranslation()
            return
        }
        val views = sugViews ?: return
        if (!pb("suggest", true) || noPredict || layer != Layer.LETTERS) {
            for (v in views) {
                v.text = ""
                v.tag = null
            }
            return
        }
        val before = beforeText()
        val w = wordOf(before)
        val prev = prevOf(before, w)
        var list = Predictor.suggest(curLang().dict, w, prev, 3, shift > 0)
        if (list.isEmpty() && w.isNotEmpty()) list = listOf(w)
        for (i in 0 until 3) {
            val s = list.getOrNull(i)
            views[i].text = s ?: ""
            views[i].tag = s
        }
    }

    private fun applySuggestion(s: String) {
        val ic = currentInputConnection ?: return
        val before = beforeText()
        val w = wordOf(before)
        val prev = prevOf(before, w)
        if (w.isNotEmpty()) ic.deleteSurroundingText(w.length, 0)
        ic.commitText("$s ", 1)
        lastSpace = 0L
        if (shift == 1) {
            shift = 0
            render()
        } else {
            updateSuggestions()
        }
        autoCap()
    }

    // ------------------------------------------------------------------ translation

    private fun autoTranslate(word: String) {
        val src = ps("tr_src", "en")
        val tgt = ps("tr_tgt", "ar")
        Translator.translate(word, src, tgt) { res ->
            if (!res.isNullOrEmpty()) {
                val ic = currentInputConnection
                if (ic != null) {
                    val before = ic.getTextBeforeCursor(word.length + 1, 0)?.toString() ?: ""
                    if (before == "$word ") {
                        ic.deleteSurroundingText(word.length + 1, 0)
                        ic.commitText("$res ", 1)
                        updateSuggestions()
                    }
                }
            }
        }
    }

    private fun scheduleTranslation() {
        handler.removeCallbacks(trRunnable)
        handler.postDelayed(trRunnable, 450)
    }

    private fun doChunkTranslate() {
        val tv = trView ?: return
        if (pb("tr_auto", true)) {
            tv.text = t("Auto: type a word then space", "اكتب كلمة ثم مسافة لترجمتها")
            return
        }
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(150, 0)?.toString() ?: ""
        val start = before.lastIndexOf('\n') + 1
        val raw = before.substring(start)
        val text = raw.trim()
        if (text.isEmpty()) {
            tv.text = ""
            trResult = null
            return
        }
        trChunkRaw = raw
        Translator.translate(text, ps("tr_src", "en"), ps("tr_tgt", "ar")) { res ->
            if (trChunkRaw == raw) {
                trResult = res
                trView?.text = res ?: "…"
            }
        }
    }

    private fun applyTranslation() {
        if (pb("tr_auto", true)) return
        val res = trResult ?: return
        val ic = currentInputConnection ?: return
        val raw = trChunkRaw
        val cur = ic.getTextBeforeCursor(raw.length, 0)?.toString() ?: ""
        if (raw.isEmpty() || cur != raw) return
        ic.deleteSurroundingText(raw.length, 0)
        ic.commitText(res + (if (raw.endsWith(" ")) " " else ""), 1)
        trResult = null
        updateSuggestions()
    }

    // ------------------------------------------------------------------ feedback

    private fun feedback(v: View) {
        if (pb("haptic", true)) {
            val ms = pi("vib_ms", 0)
            if (ms > 0) {
                try {
                    val vib = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    vib.vibrate(VibrationEffect.createOneShot(ms.toLong(), VibrationEffect.DEFAULT_AMPLITUDE))
                } catch (_: Throwable) {
                }
            } else {
                v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            }
        }
        if (pb("sound", false)) {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD, pi("vol", 50) / 100f)
        }
    }
}
