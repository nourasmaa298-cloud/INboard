package com.inboard.keyboard

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.SpannableString
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File

class SettingsActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var root: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var body: LinearLayout
    private lateinit var full: FrameLayout
    private lateinit var testBar: LinearLayout
    private var page = "home"

    private var dark = false
    private var cBg = 0
    private var cCard = 0
    private var cText = 0
    private var cSub = 0
    private val cAccent = 0xFF0A84FF.toInt()
    private val presetChips = ArrayList<TextView>()
    private val accentDots = ArrayList<View>()

    private fun t(en: String, ar: String): String = Ui.t(this, en, ar)
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun pi(k: String, d: Int): Int = prefs.getInt(k, d)
    private fun pb(k: String, d: Boolean): Boolean = prefs.getBoolean(k, d)
    private fun ps(k: String, d: String): String = prefs.getString(k, d) ?: d

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        setTheme(if (dark) android.R.style.Theme_Material_NoActionBar else android.R.style.Theme_Material_Light_NoActionBar)
        super.onCreate(savedInstanceState)
        prefs = Prefs.get(this)
        Predictor.init(this)
        cBg = if (dark) 0xFF0E0F13.toInt() else 0xFFF2F2F7.toInt()
        cCard = if (dark) 0xFF1A1C21.toInt() else Color.WHITE
        cText = if (dark) 0xFFF2F3F5.toInt() else 0xFF1C1C1E.toInt()
        cSub = if (dark) 0xFF9A9DA6.toInt() else 0xFF6B6E75.toInt()

        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(cBg)
        scroll = ScrollView(this)
        body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(16), dp(24), dp(16), dp(28))
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        full = FrameLayout(this)
        full.visibility = View.GONE
        root.addView(full, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        testBar = buildTestBar()
        testBar.visibility = View.GONE
        root.addView(testBar)
        setContentView(root)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        window.statusBarColor = cBg
        if (!dark) {
            try {
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            } catch (_: Throwable) {
            }
        }
        applyDirection()
        if (!pb("onboarded", false)) wizardLanguage() else showHome()
    }

    override fun onResume() {
        super.onResume()
        if (page == "home" && ::body.isInitialized && pb("onboarded", false)) showHome()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (page != "home" && page != "wiz1" && page != "wiz2" && pb("onboarded", false)) {
            showHome()
        } else {
            super.onBackPressed()
        }
    }

    private fun applyDirection() {
        root.layoutDirection = if (Ui.isRtl(this)) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun scrollMode() {
        full.visibility = View.GONE
        scroll.visibility = View.VISIBLE
        scroll.scrollTo(0, 0)
        body.removeAllViews()
    }

    private fun fullMode(v: View) {
        scroll.visibility = View.GONE
        testBar.visibility = View.GONE
        full.removeAllViews()
        full.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        full.visibility = View.VISIBLE
    }

    // ------------------------------------------------------------------ small ui helpers

    private fun round(color: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(r).toFloat()
        g.setColor(color)
        return g
    }

    private fun text(s: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(this)
        tv.text = s
        tv.textSize = sp
        tv.setTextColor(color)
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    private fun card(title: String?): LinearLayout {
        if (title != null) {
            val h = text(title.uppercase(), 12f, cSub, true)
            h.setPadding(dp(8), dp(20), dp(8), dp(8))
            body.addView(h)
        }
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(8), dp(16), dp(8))
        c.background = round(cCard, 18)
        body.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return c
    }

    private fun label(s: String): TextView {
        val tv = text(s, 13f, cSub)
        tv.setPadding(0, dp(12), 0, dp(4))
        return tv
    }

    private fun accentButton(s: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = s
        b.isAllCaps = false
        b.textSize = 15f
        b.setTextColor(Color.WHITE)
        b.background = round(cAccent, 14)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun smallButton(s: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = s
        b.isAllCaps = false
        b.textSize = 13f
        b.setTextColor(Color.WHITE)
        b.background = round(0xFF636366.toInt(), 12)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40))
        lp.setMargins(dp(4), dp(8), dp(4), dp(8))
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }

    private fun switchRow(c: LinearLayout, s: String, key: String, def: Boolean) {
        val sw = Switch(this)
        sw.text = s
        sw.textSize = 15f
        sw.setTextColor(cText)
        sw.isChecked = pb(key, def)
        sw.setPadding(0, dp(12), 0, dp(12))
        sw.setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
        c.addView(sw)
    }

    private fun seekRow(c: LinearLayout, s: String, key: String, min: Int, max: Int, def: Int, suffix: String) {
        val tv = text(s + ": " + pi(key, def) + suffix, 15f, cText)
        tv.setPadding(0, dp(12), 0, 0)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = (pi(key, def) - min).coerceIn(0, max - min)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + min
                tv.text = s + ": " + v + suffix
                if (fromUser) prefs.edit().putInt(key, v).apply()
            }

            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        c.addView(tv)
        c.addView(sb)
    }

    private fun actionRow(c: LinearLayout, s: String, onClick: () -> Unit): TextView {
        val tv = text(s, 15f, cAccent)
        tv.setPadding(0, dp(12), 0, dp(12))
        tv.setOnClickListener { onClick() }
        c.addView(tv)
        return tv
    }

    private fun choiceRow(c: LinearLayout, s: String, key: String, def: Int, options: List<String>) {
        val tv = text("", 15f, cText)
        tv.setPadding(0, dp(12), 0, dp(12))
        fun upd() {
            tv.text = s + ": " + options[pi(key, def).coerceIn(0, options.size - 1)]
        }
        upd()
        tv.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(s)
                .setItems(options.toTypedArray()) { _, which ->
                    prefs.edit().putInt(key, which).apply()
                    upd()
                }
                .show()
        }
        c.addView(tv)
    }

    private fun icon(type: IconDrawable.Type, sizeDp: Int, tint: Int): ImageView {
        val iv = ImageView(this)
        iv.setImageDrawable(IconDrawable(type, tint))
        iv.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        return iv
    }

    private fun buildTestBar(): LinearLayout {
        val b = LinearLayout(this)
        b.orientation = LinearLayout.HORIZONTAL
        b.setPadding(dp(14), dp(8), dp(14), dp(8))
        b.setBackgroundColor(cCard)
        val et = EditText(this)
        et.hint = t("Try the keyboard here - changes apply live", "جرّب الكيبورد هنا - التغييرات تظهر مباشرة")
        et.setTextColor(cText)
        et.setHintTextColor(cSub)
        et.maxLines = 2
        b.addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return b
    }

    // ------------------------------------------------------------------ home

    private fun imeStatus(): Pair<Boolean, Boolean> {
        var enabled = false
        var selected = false
        try {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            enabled = imm.enabledInputMethodList.any { it.packageName == packageName }
            val cur = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
            selected = cur.startsWith("$packageName/")
        } catch (_: Throwable) {
        }
        return Pair(enabled, selected)
    }

    private fun showHome() {
        page = "home"
        scrollMode()
        testBar.visibility = View.GONE
        val st = imeStatus()
        body.addView(hero(st.first, st.second))

        val setup = card(t("Setup", "الإعداد"))
        setup.addView(stepRow(1, t("Enable the keyboard", "تفعيل الكيبورد"), st.first) {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        setup.addView(stepRow(2, t("Switch to IN-board", "التبديل إلى IN-board"), st.second) {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })

        val list = card(t("Customize", "التخصيص"))
        list.addView(navRow(IconDrawable.Type.PALETTE, 0xFFAF52DE.toInt(), t("Appearance & themes", "المظهر والثيمات"), t("Colors, accent, background image", "الألوان، لون التمييز، صورة الخلفية")) { pageAppearance() })
        list.addView(navRow(IconDrawable.Type.GRID, 0xFF0A84FF.toInt(), t("Liquid Glass & blur", "الزجاج السائل والضبابية"), t("Glass look, blur, edges, gloss", "شكل الزجاج، الضبابية، الحواف، اللمعة")) { pageGlass() })
        list.addView(navRow(IconDrawable.Type.SHIFT_ON, 0xFFFF9F0A.toInt(), t("Keys & layout", "الأزرار والتخطيط"), t("Size, spacing, corners, number row", "الحجم، المسافات، الاستدارة، صف الأرقام")) { pageKeys() })
        list.addView(navRow(IconDrawable.Type.GLOBE, 0xFF30D158.toInt(), t("Languages", "اللغات"), langSummary()) { pageLanguages() })
        list.addView(navRow(IconDrawable.Type.SEARCH, 0xFF5E5CE6.toInt(), t("Typing & suggestions", "الكتابة والاقتراحات"), t("Suggestions, auto-capitalize, shortcuts", "الاقتراحات، الحروف الكبيرة، الاختصارات")) { pageTyping() })
        list.addView(navRow(IconDrawable.Type.TRANSLATE, 0xFFFF375F.toInt(), t("Translation", "الترجمة"), t("Translate whole sentences while typing", "ترجمة جمل كاملة أثناء الكتابة")) { pageTranslation() })
        list.addView(navRow(IconDrawable.Type.CLOCK, 0xFFFFD60A.toInt(), t("Haptics & sound", "الاهتزاز والصوت"), null) { pageFeedback() })
        list.addView(navRow(IconDrawable.Type.CHECK, 0xFF8E8E93.toInt(), t("About", "حول التطبيق"), "by Incertus") { pageAbout() })

        val foot = text("IN-board  |  " + t("Made by Incertus", "تم تطويره بواسطة Incertus"), 12f, cSub)
        foot.gravity = Gravity.CENTER
        foot.setPadding(0, dp(24), 0, 0)
        body.addView(foot)
    }

    private fun hero(enabled: Boolean, selected: Boolean): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(20), dp(22), dp(20), dp(18))
        val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF22242B.toInt(), 0xFF3B4C72.toInt()))
        g.cornerRadius = dp(26).toFloat()
        c.background = g

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val logo = text("IN", 24f, Color.WHITE, true)
        logo.gravity = Gravity.CENTER
        val lg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF8D9098.toInt(), 0xFF2A2B2F.toInt()))
        lg.cornerRadius = dp(18).toFloat()
        lg.setStroke(dp(1), 0x55FFFFFF)
        logo.background = lg
        top.addView(logo, LinearLayout.LayoutParams(dp(64), dp(64)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(text("IN-board", 30f, Color.WHITE, true))
        col.addView(text("by Incertus", 14f, 0xFF64D2FF.toInt(), true))
        val clp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        clp.marginStart = dp(16)
        top.addView(col, clp)
        c.addView(top)

        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        chips.addView(statusChip(t("Enabled", "مفعّل"), enabled))
        chips.addView(statusChip(t("Selected", "محدد"), selected))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(16)
        c.addView(chips, lp)

        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.VERTICAL
        wrap.addView(c)
        return wrap
    }

    private fun statusChip(label: String, ok: Boolean): TextView {
        val s = SpannableString("● $label")
        s.setSpan(ForegroundColorSpan(if (ok) 0xFF30D158.toInt() else 0xFFFF9F0A.toInt()), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val tv = TextView(this)
        tv.text = s
        tv.textSize = 13f
        tv.setTextColor(Color.WHITE)
        tv.setPadding(dp(12), dp(6), dp(12), dp(6))
        tv.background = round(0x33FFFFFF, 16)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.marginEnd = dp(8)
        tv.layoutParams = lp
        return tv
    }

    private fun stepRow(n: Int, title: String, done: Boolean, onClick: () -> Unit): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(10), 0, dp(10))
        val num = text(n.toString(), 14f, Color.WHITE, true)
        num.gravity = Gravity.CENTER
        num.background = round(if (done) 0xFF30D158.toInt() else cAccent, 14)
        r.addView(num, LinearLayout.LayoutParams(dp(28), dp(28)))
        val tt = text(title, 16f, cText)
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.marginStart = dp(12)
        r.addView(tt, lp)
        if (done) {
            r.addView(icon(IconDrawable.Type.CHECK, 22, 0xFF30D158.toInt()))
        } else {
            r.addView(text(t("Open", "فتح"), 14f, cAccent, true))
        }
        r.setOnClickListener { onClick() }
        return r
    }

    private fun navRow(type: IconDrawable.Type, color: Int, title: String, sub: String?, onClick: () -> Unit): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(10), 0, dp(10))
        val tile = FrameLayout(this)
        tile.background = round(color, 10)
        val iv = ImageView(this)
        iv.setImageDrawable(IconDrawable(type, Color.WHITE))
        tile.addView(iv, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        r.addView(tile, LinearLayout.LayoutParams(dp(36), dp(36)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(text(title, 16f, cText))
        if (sub != null) col.addView(text(sub, 12f, cSub))
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.marginStart = dp(12)
        r.addView(col, lp)
        val ch = icon(IconDrawable.Type.CHEVRON_RIGHT, 20, cSub)
        ch.scaleX = if (Ui.isRtl(this)) -1f else 1f
        r.addView(ch)
        r.setOnClickListener { onClick() }
        return r
    }

    // ------------------------------------------------------------------ sub pages

    private fun showPage(key: String, title: String, build: () -> Unit) {
        page = key
        scrollMode()
        testBar.visibility = View.VISIBLE
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        val back = icon(IconDrawable.Type.CHEVRON_LEFT, 28, cText)
        back.scaleX = if (Ui.isRtl(this)) -1f else 1f
        back.setOnClickListener { showHome() }
        bar.addView(back)
        val tv = text(title, 22f, cText, true)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.marginStart = dp(8)
        bar.addView(tv, lp)
        body.addView(bar)
        build()
    }

    private fun pageAppearance() = showPage("appearance", t("Appearance & themes", "المظهر والثيمات")) {
        presetChips.clear()
        accentDots.clear()
        val c = card(t("Theme", "الثيم"))
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val chipRow = LinearLayout(this)
        chipRow.orientation = LinearLayout.HORIZONTAL
        for (i in Themes.list.indices) {
            val p = Themes.list[i]
            val tv = text(t(p.nameEn, p.nameAr), 14f, p.text)
            tv.gravity = Gravity.CENTER
            tv.setPadding(dp(16), dp(10), dp(16), dp(10))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(dp(4), dp(8), dp(4), dp(8))
            tv.layoutParams = lp
            tv.setOnClickListener {
                prefs.edit().putInt("preset", i).apply()
                refreshChips()
            }
            presetChips.add(tv)
            chipRow.addView(tv)
        }
        hs.addView(chipRow)
        c.addView(hs)
        refreshChips()

        c.addView(label(t("Accent color", "لون التمييز")))
        val dots = LinearLayout(this)
        dots.orientation = LinearLayout.HORIZONTAL
        val choices = ArrayList<Int>()
        choices.add(0)
        choices.addAll(Themes.accents)
        for (col in choices) {
            val d = View(this)
            val lp = LinearLayout.LayoutParams(dp(32), dp(32))
            lp.setMargins(dp(4), dp(6), dp(4), dp(10))
            d.layoutParams = lp
            d.tag = col
            d.setOnClickListener {
                prefs.edit().putInt("accent", col).apply()
                refreshDots()
            }
            accentDots.add(d)
            dots.addView(d)
        }
        val dh = HorizontalScrollView(this)
        dh.isHorizontalScrollBarEnabled = false
        dh.addView(dots)
        c.addView(dh)
        refreshDots()

        val b = card(t("Background image", "صورة الخلفية"))
        val imgRow = LinearLayout(this)
        imgRow.orientation = LinearLayout.HORIZONTAL
        imgRow.addView(smallButton(t("Choose image", "اختيار صورة")) {
            val i = Intent(Intent.ACTION_GET_CONTENT)
            i.type = "image/*"
            startActivityForResult(i, 11)
        })
        imgRow.addView(smallButton(t("Remove", "إزالة")) {
            prefs.edit().putBoolean("bg_img", false).putLong("bg_ver", System.currentTimeMillis()).apply()
        })
        b.addView(imgRow)
        seekRow(b, t("Image dimming", "تعتيم الصورة"), "bg_dim", 0, 80, 35, "%")
    }

    private fun pageGlass() = showPage("glass", t("Liquid Glass & blur", "الزجاج السائل والضبابية")) {
        val gl = card(t("Liquid Glass", "الزجاج السائل"))
        choiceRow(gl, t("Style", "النمط"), "style", 0, listOf(t("Liquid Glass", "زجاج سائل"), t("Classic", "كلاسيكي")))
        seekRow(gl, t("Glass tint opacity", "كثافة لون الزجاج"), "g_panel_alpha", 5, 95, 55, "%")
        seekRow(gl, t("Key glass opacity", "كثافة زجاج الأزرار"), "g_key_alpha", 5, 95, 55, "%")
        seekRow(gl, t("Edge highlight", "لمعان الحواف"), "g_edge", 0, 100, 65, "%")
        seekRow(gl, t("Gloss / reflection", "اللمعة والانعكاس"), "g_gloss", 0, 100, 55, "%")
        seekRow(gl, t("Keyboard corner radius", "استدارة الكيبورد"), "g_radius", 0, 44, 30, "dp")
        switchRow(gl, t("Touch glow on keys", "توهّج عند لمس الأزرار"), "g_glow", true)
        switchRow(gl, t("Bottom bar (globe & mic)", "الشريط السفلي (الكرة والميكروفون)"), "bottom_bar", true)
        switchRow(gl, t("Accent color on return key", "لون التمييز على زر الإدخال"), "enter_accent", false)
        choiceRow(gl, t("Space bar", "زر المسافة"), "space_style", 0,
            listOf(t("Language code in corner", "رمز اللغة في الزاوية"), t("Language name", "اسم اللغة")))
        val bl = card(t("Blur", "الضبابية"))
        switchRow(bl, t("Blur behind the keyboard only (Android 12+)", "ضبابية خلف الكيبورد فقط (أندرويد 12+)"), "blur", true)
        seekRow(bl, t("Blur strength", "قوة الضبابية"), "blur_r", 0, 150, 80, "")
        val cl = card(t("Classic style only", "للنمط الكلاسيكي فقط"))
        seekRow(cl, t("Key opacity", "شفافية الأزرار"), "key_alpha", 20, 100, 92, "%")
        seekRow(cl, t("Keyboard opacity", "شفافية الكيبورد"), "panel_alpha", 20, 100, 82, "%")
        seekRow(cl, t("Keyboard top corner radius", "استدارة حواف الكيبورد"), "panel_r", 0, 36, 22, "dp")
    }

    private fun pageKeys() = showPage("keys", t("Keys & layout", "الأزرار والتخطيط")) {
        val lk = card(t("Keys", "الأزرار"))
        seekRow(lk, t("Key height", "ارتفاع الأزرار"), "key_h", 40, 68, 52, "dp")
        seekRow(lk, t("Key spacing", "المسافة بين الأزرار"), "gap", 0, 8, 3, "dp")
        seekRow(lk, t("Key corner radius", "استدارة الأزرار"), "key_r", 0, 26, 10, "dp")
        seekRow(lk, t("Text size", "حجم الخط"), "txt", 14, 28, 20, "sp")
        switchRow(lk, t("Bold letters", "خط عريض"), "bold", false)
        switchRow(lk, t("Key borders", "حدود للأزرار"), "border", false)
        switchRow(lk, t("Key preview popup", "معاينة الحرف عند الضغط"), "preview", true)
        val ly = card(t("Layout", "التخطيط"))
        switchRow(ly, t("Number row", "صف الأرقام"), "numrow", false)
        choiceRow(ly, t("One-handed mode", "وضع اليد الواحدة"), "onehand", 0,
            listOf(t("Off", "إيقاف"), t("Left", "يسار"), t("Right", "يمين")))
        choiceRow(ly, t("Digits", "شكل الأرقام"), "digits", 0, listOf("0123456789", "٠١٢٣٤٥٦٧٨٩"))
    }

    private fun pageLanguages() = showPage("languages", t("Languages", "اللغات")) {
        val kb = card(t("Keyboard languages", "لغات الكيبورد"))
        kb.addView(text(t("English is always the main language. Add the languages you want next to it.", "الإنجليزية هي اللغة الأساسية دائمًا. أضف اللغات التي تريدها بجانبها."), 13f, cSub))
        val sum = actionRow(kb, langSummary()) { }
        sum.setOnClickListener {
            pickerDialog(t("Keyboard languages", "لغات الكيبورد"), Langs.all.map { Pair(it.code, it.name) },
                kbCodes().toSet(), true, setOf("en")) { sel ->
                applyKbLangs(sel)
                sum.text = langSummary()
            }
        }
        choiceRow(kb, t("Digits", "شكل الأرقام"), "digits", 0, listOf("0123456789", "٠١٢٣٤٥٦٧٨٩"))

        val ui = card(t("App language", "لغة التطبيق"))
        val uiRow = actionRow(ui, t("App language: ", "لغة التطبيق: ") + TrLangs.name(Ui.effective(this))) { }
        uiRow.setOnClickListener {
            pickerDialog(t("App language", "لغة التطبيق"), TrLangs.list.filter { it.first != "auto" },
                setOf(Ui.effective(this)), false, emptySet()) { sel ->
                applyUiLanguage(sel.first()) { recreate() }
            }
        }

        val pr = card(t("Suggestions", "الاقتراحات"))
        switchRow(pr, t("Word suggestions", "اقتراح الكلمات"), "suggest", true)
        switchRow(pr, t("Auto-correct", "تصحيح تلقائي"), "autocorrect", false)
        switchRow(pr, t("Download dictionaries automatically", "تنزيل القواميس تلقائيًا"), "auto_dl", true)
        actionRow(pr, t("Download dictionaries now", "تنزيل القواميس الآن")) { downloadDicts() }
        pr.addView(text(t("The keyboard never saves or learns what you type.", "الكيبورد لا يحفظ ولا يتعلم ما تكتبه."), 12f, cSub))
    }

    private fun pageTyping() = showPage("typing", t("Typing & suggestions", "الكتابة والاقتراحات")) {
        val ty = card(t("Typing", "الكتابة"))
        switchRow(ty, t("Auto-capitalize", "حرف كبير تلقائي"), "autocap", true)
        switchRow(ty, t("Double space inserts a period", "مسافتان تدرجان نقطة"), "dotspace", true)
        switchRow(ty, t("Swipe on space bar to move cursor", "السحب على المسافة لتحريك المؤشر"), "space_swipe", true)
        seekRow(ty, t("Long-press delay", "مدة الضغط المطوّل"), "long_ms", 200, 600, 350, "ms")
        val sg = card(t("Suggestions", "الاقتراحات"))
        switchRow(sg, t("Word suggestions", "اقتراح الكلمات"), "suggest", true)
        switchRow(sg, t("Auto-correct", "تصحيح تلقائي"), "autocorrect", false)
    }

    private fun pageTranslation() = showPage("translation", t("Translation", "الترجمة")) {
        val tr = card(t("Languages (needs internet)", "اللغات (تحتاج إنترنت)"))
        val srcRow = actionRow(tr, "") { }
        val tgtRow = actionRow(tr, "") { }
        fun refreshTr() {
            srcRow.text = t("Source language: ", "لغة المصدر: ") + TrLangs.name(ps("tr_src", "en"))
            tgtRow.text = t("Target language: ", "لغة الهدف: ") + TrLangs.name(ps("tr_tgt", "ar"))
        }
        srcRow.setOnClickListener {
            pickerDialog(t("Source language", "لغة المصدر"), TrLangs.list, setOf(ps("tr_src", "en")), false, emptySet()) { sel ->
                prefs.edit().putString("tr_src", sel.first()).apply()
                refreshTr()
            }
        }
        tgtRow.setOnClickListener {
            pickerDialog(t("Target language", "لغة الهدف"), TrLangs.list.filter { it.first != "auto" }, setOf(ps("tr_tgt", "ar")), false, emptySet()) { sel ->
                prefs.edit().putString("tr_tgt", sel.first()).apply()
                refreshTr()
            }
        }
        refreshTr()
        val md = card(t("How it works", "طريقة العمل"))
        choiceRow(md, t("Mode", "الوضع"), "tr_mode", 1,
            listOf(t("Tap the translation to replace", "اضغط الترجمة للاستبدال"), t("Auto-translate at . ? ! or Enter", "ترجمة تلقائية عند . ؟ ! أو Enter")))
        md.addView(text(t("Type a whole sentence in the keyboard's translate mode (grid icon, then translate icon). The sentence is translated as one piece, so the words stay connected.", "اكتب جملة كاملة في وضع الترجمة بالكيبورد (أيقونة الشبكة ثم أيقونة الترجمة). تُترجم الجملة كاملة كقطعة واحدة فتبقى الكلمات مترابطة."), 13f, cSub))
    }

    private fun pageFeedback() = showPage("feedback", t("Haptics & sound", "الاهتزاز والصوت")) {
        val fb = card(t("Feedback", "الاستجابة"))
        switchRow(fb, t("Haptic feedback", "اهتزاز عند الضغط"), "haptic", true)
        seekRow(fb, t("Vibration length (0 = system)", "مدة الاهتزاز (0 = النظام)"), "vib_ms", 0, 40, 0, "ms")
        switchRow(fb, t("Key sound", "صوت الأزرار"), "sound", false)
        seekRow(fb, t("Sound volume", "مستوى الصوت"), "vol", 5, 100, 50, "%")
    }

    private fun pageAbout() = showPage("about", t("About", "حول التطبيق")) {
        val ab = card(null)
        val tv = text("IN-board 1.0", 18f, cText, true)
        tv.setPadding(0, dp(12), 0, dp(4))
        ab.addView(tv)
        ab.addView(text(t("Made by Incertus", "تم تطويره بواسطة Incertus"), 15f, cText))
        val cp = text("(c) 2026 Incertus. " + t("All rights reserved.", "جميع الحقوق محفوظة."), 13f, cSub)
        cp.setPadding(0, dp(4), 0, dp(12))
        ab.addView(cp)
        val rs = card(t("Reset", "إعادة الضبط"))
        actionRow(rs, t("Reset all settings", "إعادة كل الإعدادات")) {
            val keep = ps("ui_lang", "")
            prefs.edit().clear().putBoolean("onboarded", true).putString("ui_lang", keep).apply()
            toast(t("Settings reset", "تمت إعادة الضبط"))
            recreate()
        }
    }

    private fun refreshChips() {
        val cur = pi("preset", 0)
        for (i in presetChips.indices) {
            val p = Themes.list[i]
            val g = round(p.panel, 14)
            g.setStroke(dp(if (i == cur) 3 else 1), if (i == cur) cAccent else 0x33808080)
            presetChips[i].background = g
        }
    }

    private fun refreshDots() {
        val cur = pi("accent", 0)
        for (d in accentDots) {
            val col = d.tag as Int
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(if (col == 0) 0xFFB0B3BA.toInt() else col)
            g.setStroke(dp(if (col == cur) 3 else 1), if (col == cur) cText else 0x33808080)
            d.background = g
        }
    }

    // ------------------------------------------------------------------ languages helpers

    private fun kbCodes(): List<String> {
        val l = ps("langs", "en,ar").split(",").map { it.trim() }.filter { it.isNotEmpty() }.toMutableList()
        l.remove("en")
        l.add(0, "en")
        return l
    }

    private fun langSummary(): String =
        kbCodes().joinToString("  \u2022  ") { Langs.byCode(it)?.name ?: it }

    private fun applyKbLangs(sel: Set<String>) {
        val rest = Langs.all.filter { sel.contains(it.code) && it.code != "en" }.map { it.code }
        val list = ArrayList<String>()
        list.add("en")
        list.addAll(rest)
        prefs.edit().putString("langs", list.joinToString(",")).putString("cur_lang", "en").apply()
        downloadDicts()
    }

    private fun downloadDicts() {
        var started = 0
        for (c in kbCodes()) {
            val lang = Langs.byCode(c) ?: continue
            val code = lang.dict
            if (code.isEmpty() || Predictor.hasDict(this, code)) continue
            started++
            Predictor.download(this, code) { ok ->
                toast(lang.name + ": " + (if (ok) t("dictionary ready", "تم تنزيل القاموس") else t("download failed (check internet)", "فشل التنزيل (تحقق من الإنترنت)")))
            }
        }
        if (started > 0) toast(t("Downloading dictionaries...", "جارٍ تنزيل القواميس..."))
    }

    // ------------------------------------------------------------------ picker (search + list)

    private fun buildPicker(
        all: List<Pair<String, String>>,
        initial: Set<String>,
        multi: Boolean,
        locked: Set<String>,
        onChange: (Set<String>) -> Unit
    ): View {
        val sel = HashSet<String>(initial)
        val shown = ArrayList<Pair<String, String>>(all)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val et = EditText(this)
        et.hint = t("Search...", "بحث...")
        et.setTextColor(cText)
        et.setHintTextColor(cSub)
        et.setSingleLine(true)
        box.addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val lv = ListView(this)
        lv.setBackgroundColor(Color.TRANSPARENT)
        val adapter = object : BaseAdapter() {
            override fun getCount(): Int = shown.size
            override fun getItem(position: Int): Any = shown[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val p = shown[position]
                val r = LinearLayout(this@SettingsActivity)
                r.orientation = LinearLayout.HORIZONTAL
                r.gravity = Gravity.CENTER_VERTICAL
                r.setPadding(dp(8), dp(12), dp(8), dp(12))
                val on = sel.contains(p.first)
                val tv = text(p.second, 16f, if (on) cAccent else cText, on)
                r.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                if (on) r.addView(icon(IconDrawable.Type.CHECK, 22, cAccent))
                return r
            }
        }
        lv.adapter = adapter
        lv.setOnItemClickListener { _, _, pos, _ ->
            val code = shown[pos].first
            if (!locked.contains(code)) {
                if (multi) {
                    if (!sel.add(code)) sel.remove(code)
                } else {
                    sel.clear()
                    sel.add(code)
                }
                adapter.notifyDataSetChanged()
                onChange(HashSet(sel))
            }
        }
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val q = (s?.toString() ?: "").trim().lowercase()
                shown.clear()
                for (p in all) {
                    if (q.isEmpty() || p.second.lowercase().contains(q) || p.first.lowercase().contains(q)) shown.add(p)
                }
                adapter.notifyDataSetChanged()
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        box.addView(lv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        return box
    }

    private fun pickerDialog(
        title: String,
        all: List<Pair<String, String>>,
        initial: Set<String>,
        multi: Boolean,
        locked: Set<String>,
        onDone: (Set<String>) -> Unit
    ) {
        var result: Set<String> = initial
        val holder = arrayOfNulls<AlertDialog>(1)
        val view = buildPicker(all, initial, multi, locked) { s ->
            result = s
            if (!multi) {
                holder[0]?.dismiss()
                onDone(s)
            }
        }
        view.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(420))
        val b = AlertDialog.Builder(this).setTitle(title).setView(view)
        if (multi) {
            b.setPositiveButton(t("OK", "موافق")) { _, _ -> onDone(result) }
            b.setNegativeButton(t("Cancel", "إلغاء"), null)
        }
        val d = b.create()
        holder[0] = d
        d.show()
    }

    // ------------------------------------------------------------------ app language + wizard

    private fun applyUiLanguage(code: String, then: () -> Unit) {
        if (code == "en" || code == "ar" || Ui.hasCache(this, code)) {
            prefs.edit().putString("ui_lang", code).apply()
            Ui.reload()
            then()
            return
        }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(16), dp(24), dp(8))
        val msg = TextView(this)
        msg.text = "Translating the interface...  /  جارٍ ترجمة الواجهة..."
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        bar.max = 100
        box.addView(msg)
        box.addView(bar)
        val dlg = AlertDialog.Builder(this).setView(box).setCancelable(false).create()
        dlg.show()
        Ui.translateAll(this, code, { d, n ->
            bar.max = n
            bar.progress = d
        }) { ok ->
            try {
                dlg.dismiss()
            } catch (_: Exception) {
            }
            prefs.edit().putString("ui_lang", code).apply()
            Ui.reload()
            if (!ok) toast(t("Translation needs internet - English is used where missing", "الترجمة تحتاج إنترنت - تُستخدم الإنجليزية حيث ينقص"))
            then()
        }
    }

    private fun wizardPage(title: String, subtitle: String): LinearLayout {
        val v = LinearLayout(this)
        v.orientation = LinearLayout.VERTICAL
        v.setPadding(dp(18), dp(36), dp(18), dp(12))
        v.setBackgroundColor(cBg)
        v.addView(text(title, 26f, cText, true))
        val st = text(subtitle, 14f, cSub)
        st.setPadding(0, dp(6), 0, dp(12))
        v.addView(st)
        return v
    }

    private fun wizardLanguage() {
        page = "wiz1"
        val v = wizardPage("Choose your language  \u2022  \u0627\u062e\u062a\u0631 \u0644\u063a\u062a\u0643",
            "This is the language of the app. You can change it later.  \u2022  \u0647\u0630\u0647 \u0644\u063a\u0629 \u0627\u0644\u062a\u0637\u0628\u064a\u0642\u060c \u064a\u0645\u0643\u0646 \u062a\u063a\u064a\u064a\u0631\u0647\u0627 \u0644\u0627\u062d\u0642\u064b\u0627.")
        val picker = buildPicker(TrLangs.list.filter { it.first != "auto" }, setOf(Ui.effective(this)), false, emptySet()) { sel ->
            applyUiLanguage(sel.first()) {
                applyDirection()
                wizardKeyboard()
            }
        }
        v.addView(picker, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        fullMode(v)
    }

    private fun wizardKeyboard() {
        page = "wiz2"
        var second: String? = null
        val v = wizardPage(
            t("Second keyboard language", "لغة الكيبورد الثانية"),
            t("English is always the main language. Pick the language you want next to it (you can add more later).",
                "الإنجليزية هي اللغة الأساسية دائمًا. اختر اللغة التي تريدها بجانبها (ويمكنك إضافة المزيد لاحقًا).")
        )
        val picker = buildPicker(Langs.all.filter { it.code != "en" }.map { Pair(it.code, it.name) }, emptySet(), false, emptySet()) { sel ->
            second = sel.firstOrNull()
        }
        v.addView(picker, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val finish = {
            val sc = second
            val list = if (sc != null) "en,$sc" else "en"
            prefs.edit().putString("langs", list).putString("cur_lang", "en").putBoolean("onboarded", true).apply()
            if (sc != null && TrLangs.list.any { it.first == sc }) prefs.edit().putString("tr_tgt", sc).apply()
            downloadDicts()
            showHome()
        }
        val skip = smallButton(t("Skip", "تخطي")) {
            second = null
            finish()
        }
        row.addView(skip)
        val go = accentButton(t("Continue", "متابعة")) { finish() }
        row.addView(go, LinearLayout.LayoutParams(0, dp(48), 1f))
        v.addView(row)
        fullMode(v)
    }

    // ------------------------------------------------------------------ image picker

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 11 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / (s * 2) >= 1080) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            if (bmp == null) {
                toast(t("Could not read image", "تعذّر قراءة الصورة"))
                return
            }
            File(filesDir, "bg.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            prefs.edit().putBoolean("bg_img", true).putLong("bg_ver", System.currentTimeMillis()).apply()
        } catch (e: Exception) {
            toast(t("Could not read image", "تعذّر قراءة الصورة"))
        }
    }
}
