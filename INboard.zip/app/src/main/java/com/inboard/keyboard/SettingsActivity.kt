package com.inboard.keyboard

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class SettingsActivity : Activity() {

    private lateinit var prefs: SharedPreferences

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("inboard", MODE_PRIVATE)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(22), dp(48), dp(22), dp(32))

        val title = TextView(this)
        title.text = "INboard"
        title.textSize = 34f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(0xFF1C1C1E.toInt())
        col.addView(title)

        val tag = TextView(this)
        tag.text = getString(R.string.tagline)
        tag.textSize = 15f
        tag.setTextColor(0xFF6B6E75.toInt())
        tag.setPadding(0, dp(4), 0, dp(20))
        col.addView(tag)

        col.addView(button(R.string.enable) {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        col.addView(button(R.string.select) {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        })

        col.addView(section(R.string.options))
        col.addView(switchRow(R.string.haptic, "haptic", true))
        col.addView(switchRow(R.string.sound, "sound", false))
        col.addView(switchRow(R.string.blur, "blur", true))
        col.addView(switchRow(R.string.dotspace, "dotspace", true))

        col.addView(section(R.string.theme))
        col.addView(radios("theme", listOf(R.string.auto, R.string.light, R.string.dark), 0))

        col.addView(section(R.string.height))
        col.addView(radios("height", listOf(R.string.small, R.string.medium, R.string.large), 1))

        col.addView(section(R.string.try_it))
        val et = EditText(this)
        et.hint = getString(R.string.hint)
        col.addView(et)

        val sv = ScrollView(this)
        sv.setBackgroundColor(0xFFF2F2F7.toInt())
        sv.addView(col)
        setContentView(sv)
    }

    private fun button(textRes: Int, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = getString(textRes)
        b.isAllCaps = false
        b.textSize = 16f
        b.setTextColor(Color.WHITE)
        val bg = GradientDrawable()
        bg.cornerRadius = dp(14).toFloat()
        bg.setColor(0xFF0A84FF.toInt())
        b.background = bg
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))
        lp.bottomMargin = dp(10)
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }

    private fun section(textRes: Int): TextView {
        val t = TextView(this)
        t.text = getString(textRes)
        t.textSize = 13f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(0xFF6B6E75.toInt())
        t.setPadding(0, dp(24), 0, dp(6))
        return t
    }

    private fun switchRow(textRes: Int, key: String, def: Boolean): Switch {
        val s = Switch(this)
        s.text = getString(textRes)
        s.textSize = 16f
        s.setTextColor(0xFF1C1C1E.toInt())
        s.isChecked = prefs.getBoolean(key, def)
        s.setPadding(0, dp(10), 0, dp(10))
        s.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(key, checked).apply()
        }
        return s
    }

    private fun radios(key: String, labels: List<Int>, def: Int): RadioGroup {
        val g = RadioGroup(this)
        g.orientation = RadioGroup.VERTICAL
        val current = prefs.getInt(key, def)
        labels.forEachIndexed { i, res ->
            val rb = RadioButton(this)
            rb.id = 1000 + i
            rb.text = getString(res)
            rb.textSize = 16f
            g.addView(rb)
            if (i == current) rb.isChecked = true
        }
        g.setOnCheckedChangeListener { _, id ->
            prefs.edit().putInt(key, id - 1000).apply()
        }
        return g
    }
}
