package com.inboard.keyboard

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.Locale

class SettingsActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var col: LinearLayout
    private val presetChips = ArrayList<TextView>()
    private val accentDots = ArrayList<View>()

    private fun t(en: String, ar: String): String =
        if (Locale.getDefault().language == "ar") ar else en

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun pi(k: String, d: Int): Int = prefs.getInt(k, d)
    private fun pb(k: String, d: Boolean): Boolean = prefs.getBoolean(k, d)
    private fun ps(k: String, d: String): String = prefs.getString(k, d) ?: d

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs.get(this)
        Predictor.init(this)

        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(44), dp(18), dp(40))

        val title = TextView(this)
        title.text = "INboard"
        title.textSize = 34f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(0xFF1C1C1E.toInt())
        col.addView(title)

        val by = TextView(this)
        by.text = t("by Incertus", "بواسطة Incertus")
        by.textSize = 14f
        by.typeface = Typeface.DEFAULT_BOLD
        by.setTextColor(0xFF0A84FF.toInt())
        col.addView(by)

        val tag = TextView(this)
        tag.text = t("Modern keyboard: blur, themes, emoji, prediction & translation", "كيبورد حديث: ضبابية، ثيمات، إيموجي، تنبؤ بالكلمات وترجمة")
        tag.textSize = 14f
        tag.setTextColor(0xFF6B6E75.toInt())
        tag.setPadding(0, dp(4), 0, dp(16))
        col.addView(tag)

        col.addView(button(t("1. Enable the keyboard", "١. تفعيل الكيبورد")) {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        col.addView(button(t("2. Switch to INboard", "٢. التبديل إلى INboard")) {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })

        // ---- try it
        val tryBox = section(t("Try it (changes apply live)", "جرّب هنا (التغييرات تظهر مباشرة)"))
        val et = EditText(this)
        et.hint = t("Type something…", "اكتب شيئًا…")
        tryBox.addView(et)

        // ---- theme
        val th = section(t("Theme", "المظهر"))
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val chipRow = LinearLayout(this)
        chipRow.orientation = LinearLayout.HORIZONTAL
        for (i in Themes.list.indices) {
            val p = Themes.list[i]
            val tv = TextView(this)
            tv.text = t(p.nameEn, p.nameAr)
            tv.gravity = Gravity.CENTER
            tv.setTextColor(p.text)
            tv.textSize = 14f
            tv.setPadding(dp(16), dp(10), dp(16), dp(10))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(dp(4), dp(6), dp(4), dp(6))
            tv.layoutParams = lp
            tv.setOnClickListener {
                prefs.edit().putInt("preset", i).apply()
                refreshChips()
            }
            presetChips.add(tv)
            chipRow.addView(tv)
        }
        hs.addView(chipRow)
        th.addView(hs)
        refreshChips()

        th.addView(label(t("Accent color", "لون التمييز")))
        val dots = LinearLayout(this)
        dots.orientation = LinearLayout.HORIZONTAL
        val choices = ArrayList<Int>()
        choices.add(0)
        choices.addAll(Themes.accents)
        for (c in choices) {
            val d = View(this)
            val lp = LinearLayout.LayoutParams(dp(30), dp(30))
            lp.setMargins(dp(4), dp(6), dp(4), dp(6))
            d.layoutParams = lp
            d.tag = c
            d.setOnClickListener {
                prefs.edit().putInt("accent", c).apply()
                refreshDots()
            }
            accentDots.add(d)
            dots.addView(d)
        }
        val dh = HorizontalScrollView(this)
        dh.isHorizontalScrollBarEnabled = false
        dh.addView(dots)
        th.addView(dh)
        refreshDots()

        th.addView(label(t("Background image", "صورة الخلفية")))
        val imgRow = LinearLayout(this)
        imgRow.orientation = LinearLayout.HORIZONTAL
        imgRow.addView(smallButton(t("Choose image", "اختيار صورة")) {
            val i = Intent(Intent.ACTION_GET_CONTENT)
            i.type = "image/*"
            startActivityForResult(i, 11)
        })
        imgRow.addView(smallButton(t("Remove", "إزالة")) {
            prefs.edit().putBoolean("bg_img", false).putLong("bg_ver", System.currentTimeMillis()).apply()
        })
        th.addView(imgRow)
        seekRow(th, t("Image dimming", "تعتيم الصورة"), "bg_dim", 0, 80, 35, "%")

        // ---- liquid glass
        val gl = section(t("Liquid Glass", "الزجاج السائل"))
        choiceRow(gl, t("Style", "النمط"), "style", 0,
            listOf(t("Liquid Glass", "زجاج سائل"), t("Classic", "كلاسيكي")))
        seekRow(gl, t("Glass tint opacity", "كثافة لون الزجاج"), "g_panel_alpha", 5, 95, 55, "%")
        seekRow(gl, t("Key glass opacity", "كثافة زجاج الأزرار"), "g_key_alpha", 5, 95, 55, "%")
        seekRow(gl, t("Edge highlight", "لمعان الحواف"), "g_edge", 0, 100, 65, "%")
        seekRow(gl, t("Gloss / reflection", "اللمعة والانعكاس"), "g_gloss", 0, 100, 55, "%")
        seekRow(gl, t("Keyboard corner radius", "استدارة الكيبورد"), "g_radius", 0, 44, 30, "dp")
        switchRow(gl, t("Touch glow on keys", "توهّج عند لمس الأزرار"), "g_glow", true)
        switchRow(gl, t("Bottom bar (globe & mic)", "الشريط السفلي (الكرة والميكروفون)"), "bottom_bar", true)
        switchRow(gl, t("Accent color on return key", "لون التمييز على زر الإدخال"), "enter_accent", false)
        choiceRow(gl, t("Space bar", "زر المسافة"), "space_style", 0,
            listOf(t("Language code in corner", "رمز اللغة في الزاوية"), t("Language name", "اسم اللغة")))

        // ---- look
        val lk = section(t("Keys & layout", "الأزرار والتخطيط"))
        seekRow(lk, t("Key height", "ارتفاع الأزرار"), "key_h", 40, 68, 52, "dp")
        seekRow(lk, t("Key spacing", "المسافة بين الأزرار"), "gap", 0, 8, 3, "dp")
        seekRow(lk, t("Key corner radius", "استدارة الأزرار"), "key_r", 0, 26, 10, "dp")
        seekRow(lk, t("Keyboard top corner radius", "استدارة حواف الكيبورد"), "panel_r", 0, 36, 22, "dp")
        seekRow(lk, t("Key opacity", "شفافية الأزرار"), "key_alpha", 20, 100, 92, "%")
        seekRow(lk, t("Keyboard opacity", "شفافية الكيبورد"), "panel_alpha", 20, 100, 82, "%")
        seekRow(lk, t("Text size", "حجم الخط"), "txt", 14, 28, 20, "sp")
        switchRow(lk, t("Bold letters", "خط عريض"), "bold", false)
        switchRow(lk, t("Key borders", "حدود للأزرار"), "border", false)
        switchRow(lk, t("Key preview popup", "معاينة الحرف عند الضغط"), "preview", true)
        switchRow(lk, t("Number row", "صف الأرقام"), "numrow", false)
        choiceRow(lk, t("One-handed mode", "وضع اليد الواحدة"), "onehand", 0,
            listOf(t("Off", "إيقاف"), t("Left", "يسار"), t("Right", "يمين")))
        choiceRow(lk, t("Digits", "شكل الأرقام"), "digits", 0,
            listOf("0123456789", "٠١٢٣٤٥٦٧٨٩"))

        // ---- blur
        val bl = section(t("Blur", "الضبابية"))
        switchRow(bl, t("Blur behind the keyboard only (Android 12+)", "ضبابية خلف الكيبورد فقط (أندرويد 12+)"), "blur", true)
        seekRow(bl, t("Blur strength", "قوة الضبابية"), "blur_r", 0, 150, 80, "")

        // ---- languages
        val lg = section(t("Languages & prediction", "اللغات والتنبؤ"))
        actionRow(lg, t("Choose keyboard languages", "اختيار لغات الكيبورد")) { pickLanguages() }
        switchRow(lg, t("Word suggestions", "اقتراح الكلمات"), "suggest", true)
        switchRow(lg, t("Auto-correct", "تصحيح تلقائي"), "autocorrect", false)
        switchRow(lg, t("Download dictionaries automatically", "تنزيل القواميس تلقائيًا"), "auto_dl", true)
        actionRow(lg, t("Download dictionaries now", "تنزيل القواميس الآن")) { downloadDicts() }

        // ---- typing
        val ty = section(t("Typing", "الكتابة"))
        switchRow(ty, t("Auto-capitalize", "حرف كبير تلقائي"), "autocap", true)
        switchRow(ty, t("Double space inserts a period", "مسافتان تدرجان نقطة"), "dotspace", true)
        switchRow(ty, t("Swipe on space bar to move cursor", "السحب على المسافة لتحريك المؤشر"), "space_swipe", true)
        seekRow(ty, t("Long-press delay", "مدة الضغط المطوّل"), "long_ms", 200, 600, 350, "ms")

        // ---- translation
        val tr = section(t("Translation (needs internet)", "الترجمة (تحتاج إنترنت)"))
        val srcRow = actionRow(tr, "") { }
        val tgtRow = actionRow(tr, "") { }
        fun refreshTr() {
            srcRow.text = t("Source language: ", "لغة المصدر: ") + TrLangs.name(ps("tr_src", "en"))
            tgtRow.text = t("Target language: ", "لغة الهدف: ") + TrLangs.name(ps("tr_tgt", "ar"))
        }
        srcRow.setOnClickListener { pickTr(t("Source language", "لغة المصدر"), "tr_src", true) { refreshTr() } }
        tgtRow.setOnClickListener { pickTr(t("Target language", "لغة الهدف"), "tr_tgt", false) { refreshTr() } }
        refreshTr()
        switchRow(tr, t("Auto-replace each word with its translation when pressing space", "استبدال كل كلمة بترجمتها تلقائيًا عند المسافة"), "tr_auto", true)
        tr.addView(label(t("In the keyboard: tap the grid icon, then the translate icon.", "في الكيبورد: اضغط أيقونة الشبكة ثم أيقونة الترجمة.")))

        // ---- feedback
        val fb = section(t("Feedback", "الاهتزاز والصوت"))
        switchRow(fb, t("Haptic feedback", "اهتزاز عند الضغط"), "haptic", true)
        seekRow(fb, t("Vibration length (0 = system)", "مدة الاهتزاز (0 = النظام)"), "vib_ms", 0, 40, 0, "ms")
        switchRow(fb, t("Key sound", "صوت الأزرار"), "sound", false)
        seekRow(fb, t("Sound volume", "مستوى الصوت"), "vol", 5, 100, 50, "%")

        // ---- reset
        val rs = section(t("Reset", "إعادة الضبط"))
        actionRow(rs, t("Reset all settings", "إعادة كل الإعدادات")) {
            prefs.edit().clear().apply()
            toast(t("Settings reset", "تمت إعادة الضبط"))
            recreate()
        }

        val ab = section(t("About", "حول التطبيق"))
        val abt = TextView(this)
        abt.text = "INboard 1.0\n" + t("Made by Incertus", "تم تطويره بواسطة Incertus") + "\n© 2026 Incertus. " +
            t("All rights reserved.", "جميع الحقوق محفوظة.")
        abt.textSize = 15f
        abt.setTextColor(0xFF1C1C1E.toInt())
        abt.setPadding(0, dp(10), 0, dp(10))
        ab.addView(abt)

        val sv = ScrollView(this)
        sv.setBackgroundColor(0xFFF2F2F7.toInt())
        sv.addView(col)
        setContentView(sv)
        window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
    }

    // ------------------------------------------------------------------ ui helpers

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun section(title: String): LinearLayout {
        val h = TextView(this)
        h.text = title.uppercase()
        h.textSize = 12f
        h.typeface = Typeface.DEFAULT_BOLD
        h.setTextColor(0xFF6B6E75.toInt())
        h.setPadding(dp(6), dp(22), 0, dp(6))
        col.addView(h)
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(14), dp(8), dp(14), dp(8))
        val g = GradientDrawable()
        g.cornerRadius = dp(16).toFloat()
        g.setColor(Color.WHITE)
        c.background = g
        col.addView(c)
        return c
    }

    private fun label(s: String): TextView {
        val tv = TextView(this)
        tv.text = s
        tv.textSize = 13f
        tv.setTextColor(0xFF6B6E75.toInt())
        tv.setPadding(0, dp(10), 0, dp(2))
        return tv
    }

    private fun button(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 16f
        b.setTextColor(Color.WHITE)
        val bg = GradientDrawable()
        bg.cornerRadius = dp(14).toFloat()
        bg.setColor(0xFF0A84FF.toInt())
        b.background = bg
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))
        lp.bottomMargin = dp(10)
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }

    private fun smallButton(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 14f
        b.setTextColor(Color.WHITE)
        val bg = GradientDrawable()
        bg.cornerRadius = dp(12).toFloat()
        bg.setColor(0xFF636366.toInt())
        b.background = bg
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42))
        lp.setMargins(dp(4), dp(8), dp(4), dp(8))
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }

    private fun switchRow(c: LinearLayout, text: String, key: String, def: Boolean) {
        val s = Switch(this)
        s.text = text
        s.textSize = 15f
        s.setTextColor(0xFF1C1C1E.toInt())
        s.isChecked = pb(key, def)
        s.setPadding(0, dp(10), 0, dp(10))
        s.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(key, checked).apply()
        }
        c.addView(s)
    }

    private fun seekRow(c: LinearLayout, text: String, key: String, min: Int, max: Int, def: Int, suffix: String) {
        val tv = TextView(this)
        tv.textSize = 15f
        tv.setTextColor(0xFF1C1C1E.toInt())
        tv.setPadding(0, dp(10), 0, 0)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = pi(key, def) - min
        tv.text = text + ": " + pi(key, def) + suffix
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + min
                tv.text = text + ": " + v + suffix
                if (fromUser) prefs.edit().putInt(key, v).apply()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        c.addView(tv)
        c.addView(sb)
    }

    private fun actionRow(c: LinearLayout, text: String, onClick: () -> Unit): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 15f
        tv.setTextColor(0xFF0A84FF.toInt())
        tv.setPadding(0, dp(12), 0, dp(12))
        tv.setOnClickListener { onClick() }
        c.addView(tv)
        return tv
    }

    private fun choiceRow(c: LinearLayout, text: String, key: String, def: Int, options: List<String>) {
        val tv = TextView(this)
        tv.textSize = 15f
        tv.setTextColor(0xFF1C1C1E.toInt())
        tv.setPadding(0, dp(12), 0, dp(12))
        fun upd() {
            tv.text = text + ": " + options[pi(key, def).coerceIn(0, options.size - 1)]
        }
        upd()
        tv.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(text)
                .setItems(options.toTypedArray()) { _, which ->
                    prefs.edit().putInt(key, which).apply()
                    upd()
                }
                .show()
        }
        c.addView(tv)
    }

    private fun refreshChips() {
        val cur = pi("preset", 0)
        for (i in presetChips.indices) {
            val p = Themes.list[i]
            val g = GradientDrawable()
            g.cornerRadius = dp(14).toFloat()
            g.setColor(p.panel)
            g.setStroke(dp(if (i == cur) 3 else 1), if (i == cur) 0xFF0A84FF.toInt() else 0x33000000)
            presetChips[i].background = g
        }
    }

    private fun refreshDots() {
        val cur = pi("accent", 0)
        for (d in accentDots) {
            val c = d.tag as Int
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(if (c == 0) 0xFFD1D3D9.toInt() else c)
            g.setStroke(dp(if (c == cur) 3 else 1), if (c == cur) 0xFF1C1C1E.toInt() else 0x33000000)
            d.background = g
        }
    }

    // ------------------------------------------------------------------ dialogs

    private fun pickLanguages() {
        val all = Langs.all
        val cur = ps("langs", "en,ar").split(",").map { it.trim() }
        val names = all.map { it.name + " (" + it.code + ")" }.toTypedArray()
        val checked = BooleanArray(all.size) { cur.contains(all[it].code) }
        AlertDialog.Builder(this)
            .setTitle(t("Keyboard languages", "لغات الكيبورد"))
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton(t("OK", "موافق")) { _, _ ->
                val sel = ArrayList<String>()
                for (i in all.indices) if (checked[i]) sel.add(all[i].code)
                if (sel.isEmpty()) {
                    toast(t("Pick at least one language", "اختر لغة واحدة على الأقل"))
                } else {
                    prefs.edit().putString("langs", sel.joinToString(",")).apply()
                    downloadDicts()
                }
            }
            .setNegativeButton(t("Cancel", "إلغاء"), null)
            .show()
    }

    private fun downloadDicts() {
        val codes = ps("langs", "en,ar").split(",").map { it.trim() }
        var started = 0
        for (c in codes) {
            val lang = Langs.byCode(c) ?: continue
            val code = lang.dict
            if (code.isEmpty() || Predictor.hasDict(this, code)) continue
            started++
            Predictor.download(this, code) { ok ->
                toast(lang.name + ": " + (if (ok) t("dictionary ready", "تم تنزيل القاموس") else t("download failed (check internet)", "فشل التنزيل (تحقق من الإنترنت)")))
            }
        }
        if (started == 0) toast(t("All dictionaries are already downloaded", "كل القواميس منزّلة بالفعل"))
        else toast(t("Downloading…", "جارٍ التنزيل…"))
    }

    private fun pickTr(title: String, key: String, withAuto: Boolean, done: () -> Unit) {
        val list = TrLangs.list.filter { withAuto || it.first != "auto" }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(list.map { it.second }.toTypedArray()) { _, which ->
                prefs.edit().putString(key, list[which].first).apply()
                done()
            }
            .show()
    }

    // ------------------------------------------------------------------ image picker

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 11 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / (s * 2) >= 1080) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            if (bmp == null) {
                toast(t("Could not read image", "تعذّر قراءة الصورة"))
                return
            }
            File(filesDir, "bg.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            prefs.edit().putBoolean("bg_img", true).putLong("bg_ver", System.currentTimeMillis()).apply()
        } catch (e: Exception) {
            toast(t("Could not read image", "تعذّر قراءة الصورة"))
        }
    }
}
