package com.inboard.keyboard

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

/** Online translation (needs internet). Uses Google's public endpoint, falls back to MyMemory. */
object Translator {

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val cache = object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean = size > 200
    }

    fun translate(text: String, src: String, tgt: String, cb: (String?) -> Unit) {
        val key = "$src|$tgt|$text"
        val hit = synchronized(cache) { cache[key] }
        if (hit != null) {
            cb(hit)
            return
        }
        executor.execute {
            var res: String? = null
            try {
                res = google(text, src, tgt)
            } catch (_: Exception) {
            }
            if (res.isNullOrEmpty() && src != "auto") {
                try {
                    res = myMemory(text, src, tgt)
                } catch (_: Exception) {
                }
            }
            val out = res
            if (out != null && out.isNotEmpty()) synchronized(cache) { cache[key] = out }
            main.post { cb(out) }
        }
    }

    /** Blocking translation for background threads. */
    fun translateSync(text: String, src: String, tgt: String): String? {
        var res: String? = null
        try {
            res = google(text, src, tgt)
        } catch (_: Exception) {
        }
        if (res.isNullOrEmpty() && src != "auto") {
            try {
                res = myMemory(text, src, tgt)
            } catch (_: Exception) {
            }
        }
        return res
    }

    private fun get(u: String): String {
        val con = URL(u).openConnection() as HttpURLConnection
        con.connectTimeout = 8000
        con.readTimeout = 12000
        con.setRequestProperty("User-Agent", "Mozilla/5.0")
        try {
            if (con.responseCode != 200) throw Exception("HTTP " + con.responseCode)
            return con.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            con.disconnect()
        }
    }

    private fun google(text: String, src: String, tgt: String): String {
        val q = URLEncoder.encode(text, "UTF-8")
        val body = get("https://translate.googleapis.com/translate_a/single?client=gtx&sl=$src&tl=$tgt&dt=t&q=$q")
        val parts = JSONArray(body).getJSONArray(0)
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.optJSONArray(i)
            if (p != null) sb.append(p.optString(0))
        }
        return sb.toString()
    }

    private fun myMemory(text: String, src: String, tgt: String): String {
        val q = URLEncoder.encode(text, "UTF-8")
        val body = get("https://api.mymemory.translated.net/get?q=$q&langpair=$src|$tgt")
        return JSONObject(body).getJSONObject("responseData").getString("translatedText")
    }
}
