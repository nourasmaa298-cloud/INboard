package com.inboard.keyboard

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.File
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * App-interface language. English and Arabic are built in; every other language is translated
 * once from the English text (online) and cached on the phone.
 */
object Ui {
    private val main = Handler(Looper.getMainLooper())
    private var cache: Map<String, String> = HashMap()
    private var cacheLang = ""
    private val rtlLangs = setOf("ar", "fa", "ur", "he", "ps", "ckb", "sd", "ug", "yi")

    fun effective(ctx: Context): String {
        val l = Prefs.get(ctx).getString("ui_lang", "") ?: ""
        if (l.isNotEmpty()) return l
        return if (Locale.getDefault().language == "ar") "ar" else "en"
    }

    fun isRtl(ctx: Context): Boolean = rtlLangs.contains(effective(ctx))

    fun reload() {
        cacheLang = ""
    }

    private fun file(ctx: Context, lang: String): File = File(ctx.filesDir, "ui_$lang.txt")

    fun hasCache(ctx: Context, lang: String): Boolean = file(ctx, lang).exists()

    private fun ensure(ctx: Context, lang: String) {
        if (cacheLang == lang) return
        val m = HashMap<String, String>()
        try {
            val f = file(ctx, lang)
            if (f.exists()) {
                f.forEachLine { l ->
                    val i = l.indexOf('\t')
                    if (i > 0) m[l.substring(0, i)] = l.substring(i + 1)
                }
            }
        } catch (_: Exception) {
        }
        cache = m
        cacheLang = lang
    }

    fun t(ctx: Context, en: String, ar: String): String {
        val l = effective(ctx)
        if (l == "en") return en
        if (l == "ar") return ar
        ensure(ctx, l)
        return cache[en] ?: en
    }

    /** Translates every interface string into [lang]; callbacks run on the main thread. */
    fun translateAll(ctx: Context, lang: String, onProgress: (Int, Int) -> Unit, onDone: (Boolean) -> Unit) {
        val app = ctx.applicationContext
        Thread {
            val items = UiStrings.ALL
            val map = ConcurrentHashMap<String, String>()
            val pool = Executors.newFixedThreadPool(4)
            val count = AtomicInteger(0)
            val fails = AtomicInteger(0)
            val latch = CountDownLatch(items.size)
            for (s in items) {
                pool.execute {
                    if (fails.get() < 6 || map.isNotEmpty()) {
                        try {
                            val r = Translator.translateSync(s, "en", lang)
                            if (!r.isNullOrEmpty()) map[s] = r.replace("\t", " ").replace("\n", " ") else fails.incrementAndGet()
                        } catch (_: Throwable) {
                            fails.incrementAndGet()
                        }
                    }
                    val d = count.incrementAndGet()
                    main.post { onProgress(d, items.size) }
                    latch.countDown()
                }
            }
            try {
                latch.await()
            } catch (_: InterruptedException) {
            }
            pool.shutdown()
            val ok = map.size >= items.size * 8 / 10
            if (map.isNotEmpty()) {
                try {
                    val sb = StringBuilder()
                    for ((k, v) in map) sb.append(k).append('\t').append(v).append('\n')
                    file(app, lang).writeText(sb.toString())
                } catch (_: Exception) {
                }
            }
            main.post { onDone(ok) }
        }.start()
    }
}
