package com.inboard.keyboard

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable

/** Vector-like icons drawn with Canvas (no emoji, no external assets). */
class IconDrawable(private val type: Type, private var tint: Int) : Drawable() {

    enum class Type {
        GEAR, SMILEY, CLIPBOARD, GLOBE, SHIFT, SHIFT_ON, SHIFT_LOCK, BACKSPACE, RETURN, SEND,
        SEARCH, GO, CHECK, CHEVRON_DOWN, TRANSLATE, SWAP, CLOCK, ANIMALS, FOOD, ACTIVITY,
        TRAVEL, OBJECTS, SYMBOLS, FLAG, PERSON, CLOSE, GRID, PALETTE, HAND
    }

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        stroke.style = Paint.Style.STROKE
        stroke.strokeCap = Paint.Cap.ROUND
        stroke.strokeJoin = Paint.Join.ROUND
        stroke.strokeWidth = 0.075f
        fill.style = Paint.Style.FILL
    }

    fun setTintColor(c: Int) {
        tint = c
        invalidateSelf()
    }

    private fun ln(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) {
        c.drawLine(x1, y1, x2, y2, stroke)
    }

    private fun poly(c: Canvas, pts: FloatArray, close: Boolean, paint: Paint) {
        val p = Path()
        var i = 0
        while (i < pts.size) {
            if (i == 0) p.moveTo(pts[0], pts[1]) else p.lineTo(pts[i], pts[i + 1])
            i += 2
        }
        if (close) p.close()
        c.drawPath(p, paint)
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val s = minOf(b.width(), b.height()).toFloat()
        if (s <= 0f) return
        stroke.color = tint
        fill.color = tint
        canvas.save()
        canvas.translate(b.left + (b.width() - s) / 2f, b.top + (b.height() - s) / 2f)
        canvas.scale(s, s)
        when (type) {
            Type.GEAR -> {
                val p = Path()
                p.fillType = Path.FillType.EVEN_ODD
                for (i in 0 until 8) {
                    val a = i * 45.0
                    val angs = doubleArrayOf(a - 13.0, a - 8.0, a + 8.0, a + 13.0)
                    val rs = floatArrayOf(0.33f, 0.43f, 0.43f, 0.33f)
                    for (k in 0 until 4) {
                        val rad = Math.toRadians(angs[k])
                        val x = 0.5f + (rs[k] * Math.cos(rad)).toFloat()
                        val y = 0.5f + (rs[k] * Math.sin(rad)).toFloat()
                        if (i == 0 && k == 0) p.moveTo(x, y) else p.lineTo(x, y)
                    }
                }
                p.close()
                p.addCircle(0.5f, 0.5f, 0.14f, Path.Direction.CW)
                canvas.drawPath(p, fill)
            }
            Type.SMILEY -> {
                canvas.drawCircle(0.5f, 0.5f, 0.38f, stroke)
                canvas.drawCircle(0.37f, 0.41f, 0.045f, fill)
                canvas.drawCircle(0.63f, 0.41f, 0.045f, fill)
                canvas.drawArc(RectF(0.3f, 0.3f, 0.7f, 0.7f), 25f, 130f, false, stroke)
            }
            Type.CLIPBOARD -> {
                canvas.drawRoundRect(RectF(0.2f, 0.18f, 0.8f, 0.88f), 0.08f, 0.08f, stroke)
                canvas.drawRoundRect(RectF(0.36f, 0.1f, 0.64f, 0.26f), 0.05f, 0.05f, fill)
                ln(canvas, 0.34f, 0.46f, 0.66f, 0.46f)
                ln(canvas, 0.34f, 0.6f, 0.66f, 0.6f)
                ln(canvas, 0.34f, 0.74f, 0.54f, 0.74f)
            }
            Type.GLOBE -> {
                canvas.drawCircle(0.5f, 0.5f, 0.38f, stroke)
                canvas.drawOval(RectF(0.3f, 0.12f, 0.7f, 0.88f), stroke)
                ln(canvas, 0.12f, 0.5f, 0.88f, 0.5f)
                ln(canvas, 0.18f, 0.3f, 0.82f, 0.3f)
                ln(canvas, 0.18f, 0.7f, 0.82f, 0.7f)
            }
            Type.SHIFT, Type.SHIFT_ON, Type.SHIFT_LOCK -> {
                val bottom = if (type == Type.SHIFT_LOCK) 0.76f else 0.84f
                val pts = floatArrayOf(0.5f, 0.14f, 0.84f, 0.5f, 0.66f, 0.5f, 0.66f, bottom, 0.34f, bottom, 0.34f, 0.5f, 0.16f, 0.5f)
                poly(canvas, pts, true, if (type == Type.SHIFT) stroke else fill)
                if (type == Type.SHIFT_LOCK) {
                    canvas.drawRoundRect(RectF(0.34f, 0.83f, 0.66f, 0.9f), 0.03f, 0.03f, fill)
                }
            }
            Type.BACKSPACE -> {
                poly(canvas, floatArrayOf(0.1f, 0.5f, 0.34f, 0.22f, 0.88f, 0.22f, 0.88f, 0.78f, 0.34f, 0.78f), true, stroke)
                ln(canvas, 0.5f, 0.4f, 0.72f, 0.6f)
                ln(canvas, 0.72f, 0.4f, 0.5f, 0.6f)
            }
            Type.RETURN -> {
                poly(canvas, floatArrayOf(0.82f, 0.22f, 0.82f, 0.52f, 0.2f, 0.52f), false, stroke)
                poly(canvas, floatArrayOf(0.34f, 0.38f, 0.2f, 0.52f, 0.34f, 0.66f), false, stroke)
            }
            Type.SEND -> {
                poly(canvas, floatArrayOf(0.14f, 0.5f, 0.86f, 0.16f, 0.64f, 0.84f, 0.5f, 0.58f), true, stroke)
                ln(canvas, 0.5f, 0.58f, 0.86f, 0.16f)
            }
            Type.SEARCH -> {
                canvas.drawCircle(0.44f, 0.44f, 0.26f, stroke)
                ln(canvas, 0.63f, 0.63f, 0.84f, 0.84f)
            }
            Type.GO -> {
                ln(canvas, 0.16f, 0.5f, 0.84f, 0.5f)
                poly(canvas, floatArrayOf(0.58f, 0.24f, 0.84f, 0.5f, 0.58f, 0.76f), false, stroke)
            }
            Type.CHECK -> poly(canvas, floatArrayOf(0.2f, 0.54f, 0.42f, 0.74f, 0.82f, 0.28f), false, stroke)
            Type.CHEVRON_DOWN -> poly(canvas, floatArrayOf(0.24f, 0.38f, 0.5f, 0.64f, 0.76f, 0.38f), false, stroke)
            Type.TRANSLATE -> {
                canvas.drawRoundRect(RectF(0.1f, 0.12f, 0.6f, 0.62f), 0.07f, 0.07f, stroke)
                poly(canvas, floatArrayOf(0.2f, 0.5f, 0.35f, 0.22f, 0.5f, 0.5f), false, stroke)
                ln(canvas, 0.25f, 0.42f, 0.45f, 0.42f)
                canvas.drawRoundRect(RectF(0.42f, 0.4f, 0.9f, 0.88f), 0.07f, 0.07f, stroke)
                ln(canvas, 0.52f, 0.58f, 0.8f, 0.58f)
                ln(canvas, 0.66f, 0.52f, 0.66f, 0.58f)
                poly(canvas, floatArrayOf(0.58f, 0.58f, 0.62f, 0.72f, 0.72f, 0.8f), false, stroke)
                poly(canvas, floatArrayOf(0.74f, 0.58f, 0.7f, 0.7f, 0.58f, 0.8f), false, stroke)
            }
            Type.SWAP -> {
                ln(canvas, 0.2f, 0.35f, 0.8f, 0.35f)
                poly(canvas, floatArrayOf(0.64f, 0.2f, 0.8f, 0.35f, 0.64f, 0.5f), false, stroke)
                ln(canvas, 0.8f, 0.65f, 0.2f, 0.65f)
                poly(canvas, floatArrayOf(0.36f, 0.5f, 0.2f, 0.65f, 0.36f, 0.8f), false, stroke)
            }
            Type.CLOCK -> {
                canvas.drawCircle(0.5f, 0.5f, 0.38f, stroke)
                poly(canvas, floatArrayOf(0.5f, 0.26f, 0.5f, 0.5f, 0.68f, 0.6f), false, stroke)
            }
            Type.ANIMALS -> {
                canvas.drawCircle(0.5f, 0.64f, 0.17f, fill)
                canvas.drawCircle(0.25f, 0.48f, 0.08f, fill)
                canvas.drawCircle(0.4f, 0.3f, 0.085f, fill)
                canvas.drawCircle(0.6f, 0.3f, 0.085f, fill)
                canvas.drawCircle(0.75f, 0.48f, 0.08f, fill)
            }
            Type.FOOD -> {
                poly(canvas, floatArrayOf(0.2f, 0.34f, 0.7f, 0.34f, 0.64f, 0.8f, 0.26f, 0.8f), true, stroke)
                canvas.drawArc(RectF(0.58f, 0.4f, 0.84f, 0.64f), -90f, 180f, false, stroke)
                ln(canvas, 0.35f, 0.14f, 0.35f, 0.24f)
                ln(canvas, 0.52f, 0.14f, 0.52f, 0.24f)
            }
            Type.ACTIVITY -> {
                canvas.drawCircle(0.5f, 0.5f, 0.38f, stroke)
                val pp = Path()
                for (i in 0 until 5) {
                    val a = Math.toRadians(-90.0 + i * 72.0)
                    val x = 0.5f + (0.13 * Math.cos(a)).toFloat()
                    val y = 0.5f + (0.13 * Math.sin(a)).toFloat()
                    val x2 = 0.5f + (0.38 * Math.cos(a)).toFloat()
                    val y2 = 0.5f + (0.38 * Math.sin(a)).toFloat()
                    if (i == 0) pp.moveTo(x, y) else pp.lineTo(x, y)
                    ln(canvas, x, y, x2, y2)
                }
                pp.close()
                canvas.drawPath(pp, stroke)
            }
            Type.TRAVEL -> {
                canvas.drawRoundRect(RectF(0.1f, 0.44f, 0.9f, 0.7f), 0.08f, 0.08f, stroke)
                poly(canvas, floatArrayOf(0.24f, 0.44f, 0.34f, 0.28f, 0.66f, 0.28f, 0.76f, 0.44f), false, stroke)
                canvas.drawCircle(0.3f, 0.72f, 0.08f, fill)
                canvas.drawCircle(0.7f, 0.72f, 0.08f, fill)
            }
            Type.OBJECTS -> {
                canvas.drawCircle(0.5f, 0.38f, 0.23f, stroke)
                poly(canvas, floatArrayOf(0.4f, 0.58f, 0.42f, 0.7f, 0.58f, 0.7f, 0.6f, 0.58f), false, stroke)
                ln(canvas, 0.43f, 0.82f, 0.57f, 0.82f)
            }
            Type.SYMBOLS -> {
                val p = Path()
                p.moveTo(0.5f, 0.82f)
                p.cubicTo(0.1f, 0.55f, 0.14f, 0.18f, 0.34f, 0.2f)
                p.cubicTo(0.44f, 0.21f, 0.5f, 0.3f, 0.5f, 0.34f)
                p.cubicTo(0.5f, 0.3f, 0.56f, 0.21f, 0.66f, 0.2f)
                p.cubicTo(0.86f, 0.18f, 0.9f, 0.55f, 0.5f, 0.82f)
                p.close()
                canvas.drawPath(p, stroke)
            }
            Type.FLAG -> {
                ln(canvas, 0.24f, 0.14f, 0.24f, 0.9f)
                poly(canvas, floatArrayOf(0.24f, 0.18f, 0.8f, 0.18f, 0.68f, 0.38f, 0.8f, 0.58f, 0.24f, 0.58f), true, stroke)
            }
            Type.PERSON -> {
                canvas.drawCircle(0.5f, 0.3f, 0.15f, stroke)
                val p = Path()
                p.moveTo(0.2f, 0.88f)
                p.cubicTo(0.2f, 0.56f, 0.8f, 0.56f, 0.8f, 0.88f)
                canvas.drawPath(p, stroke)
            }
            Type.CLOSE -> {
                ln(canvas, 0.25f, 0.25f, 0.75f, 0.75f)
                ln(canvas, 0.75f, 0.25f, 0.25f, 0.75f)
            }
            Type.GRID -> {
                val xs = floatArrayOf(0.3f, 0.7f)
                for (x in xs) for (y in xs) canvas.drawRoundRect(RectF(x - 0.1f, y - 0.1f, x + 0.1f, y + 0.1f), 0.04f, 0.04f, fill)
            }
            Type.PALETTE -> {
                canvas.drawCircle(0.5f, 0.5f, 0.38f, stroke)
                canvas.drawCircle(0.36f, 0.44f, 0.055f, fill)
                canvas.drawCircle(0.5f, 0.32f, 0.055f, fill)
                canvas.drawCircle(0.66f, 0.44f, 0.055f, fill)
                canvas.drawCircle(0.6f, 0.62f, 0.055f, fill)
            }
            Type.HAND -> {
                canvas.drawRoundRect(RectF(0.3f, 0.1f, 0.7f, 0.9f), 0.08f, 0.08f, stroke)
                ln(canvas, 0.4f, 0.5f, 0.6f, 0.5f)
                poly(canvas, floatArrayOf(0.5f, 0.4f, 0.6f, 0.5f, 0.5f, 0.6f), false, stroke)
            }
        }
        canvas.restore()
    }

    override fun setAlpha(alpha: Int) {
        stroke.alpha = alpha
        fill.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        stroke.colorFilter = colorFilter
        fill.colorFilter = colorFilter
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Rounded-top keyboard panel with optional background image (center-crop) and dim overlay. */
class PanelDrawable(
    private val color: Int,
    private val bmp: Bitmap?,
    private val dim: Int,
    private val radius: Float
) : Drawable() {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    override fun draw(canvas: Canvas) {
        val rect = RectF(bounds)
        val path = Path()
        path.addRoundRect(
            rect,
            floatArrayOf(radius, radius, radius, radius, 0f, 0f, 0f, 0f),
            Path.Direction.CW
        )
        canvas.save()
        canvas.clipPath(path)
        if (bmp != null) {
            val sc = maxOf(rect.width() / bmp.width, rect.height() / bmp.height)
            val m = Matrix()
            m.postScale(sc, sc)
            m.postTranslate(
                rect.left + (rect.width() - bmp.width * sc) / 2f,
                rect.top + (rect.height() - bmp.height * sc) / 2f
            )
            canvas.drawBitmap(bmp, m, paint)
            paint.color = (255 * dim / 100) shl 24
            canvas.drawRect(rect, paint)
        } else {
            paint.color = color
            canvas.drawRect(rect, paint)
        }
        canvas.restore()
    }

    override fun setAlpha(alpha: Int) {}

    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
